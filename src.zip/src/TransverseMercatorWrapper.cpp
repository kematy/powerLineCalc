#include <windows.h>
#define _EXPORTDLL
#include "TransverseMercatorWrapper.hpp"  
#include "TransverseMercator.hpp"  

BOOL APIENTRY DllMain (HINSTANCE hInst     /* Library instance handle. */ ,
                       DWORD reason        /* Reason this function is being called. */ ,
                       LPVOID reserved     /* Not used. */ )
{
	switch (reason)
	{
		case DLL_PROCESS_ATTACH:
		break;

		case DLL_PROCESS_DETACH:
		break;

		case DLL_THREAD_ATTACH:
		break;

		case DLL_THREAD_DETACH:
		break;
	}

	/* Returns TRUE on success, FALSE on failure */
	return TRUE;
}

#ifdef __cplusplus  
extern "C" {  
#endif  





struct  geo_transverse_mercator
{  
	GeographicLib::TransverseMercator geo_tm;  //(double a, double f, double k0);
	double a;
	double f;
	double k0;
    	
};
//TransverseMercator;  
 
struct geo_transverse_mercator *geo_transverse_mercator_init()  
{   
   return new struct geo_transverse_mercator; 
}  
void geo_transverse_mercator_start(struct geo_transverse_mercator *pTransverseMercator,double a, double f, double k0)
{
	pTransverseMercator->geo_tm.Init(a,f,k0);
}
void geo_transverse_release_instance(struct geo_transverse_mercator **ppInstance)  
{  
    delete *ppInstance;  
    *ppInstance = 0;  
      
}  
void geo_transverse_mercator_forward(struct geo_transverse_mercator *pTransverseMercator, double lon0, double lat, double lon,
                 double& x, double& y)  
{  
    pTransverseMercator->geo_tm.Forward(lon0,lat,lon,
                 x, y);  
}  
void geo_transverse_mercator_reverse(struct geo_transverse_mercator *pTransverseMercator, double lon0, double x, double y,
                 double& lat, double& lon)  
{  
    pTransverseMercator->geo_tm.Reverse(lon0,x,y,
                 lat, lon);  
}    

#ifdef __cplusplus  
};  
#endif  