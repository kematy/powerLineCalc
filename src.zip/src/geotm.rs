
#[repr(C)]
#[derive(Copy)]
pub struct Struct_geo_transverse_mercator {
   pub a:f64,
   pub f:f64,
   pub k0:f64,
}
impl ::std::clone::Clone for Struct_geo_transverse_mercator {
    fn clone(&self) -> Self { *self }
}
impl ::std::default::Default for Struct_geo_transverse_mercator {
    fn default() -> Self { unsafe { ::std::mem::zeroed() } }
}
extern "C" {
    pub fn geo_transverse_mercator_init(g: *mut Struct_geo_transverse_mercator,
                     );
    pub fn geo_transverse_mercator_start(g: *const Struct_geo_transverse_mercator,
                     a: ::std::os::raw::c_double,
                     f: ::std::os::raw::c_double,
           k0: ::std::os::raw::c_double);
    pub fn geo_transverse_mercator_forward(g: *const Struct_geo_transverse_mercator,
                       lon0: ::std::os::raw::c_double,
                       lat: ::std::os::raw::c_double,
                       lon: ::std::os::raw::c_double,
                       x: *mut ::std::os::raw::c_double,
                       y: *mut ::std::os::raw::c_double);
	  pub fn geo_transverse_mercator_reverse(g: *const Struct_geo_transverse_mercator,
                       lon0: ::std::os::raw::c_double,
                       x: ::std::os::raw::c_double,
                       y: ::std::os::raw::c_double,
                       lat: *mut ::std::os::raw::c_double,
                       lon: *mut ::std::os::raw::c_double);
  
}
