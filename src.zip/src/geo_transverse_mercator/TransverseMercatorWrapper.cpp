
#include "TransverseMercatorWrapper.hpp"  
#include "TransverseMercator.hpp"  
  
#ifdef __cplusplus  
extern "C" {  
#endif  
struct geo_transverse_mercator  
{  
    GeographicLib::TransverseMercator TransverseMercator;  
};  
struct geo_transverse_mercator *GetInstance(double a, double f, double k0)  
{  
    return new struct geo_transverse_mercator(a,f,k0);  
}  
void ReleaseInstance(struct geo_transverse_mercator **ppInstance)  
{  
    delete *ppInstance;  
    *ppInstance = 0;  
      
}  
void Forward(struct geo_transverse_mercator *pTransverseMercator, double lon0, double lat, double lon,
                 double& x, double& y)  
{  
    pTransverseMercator->GeographicLib::TransverseMercator.Forward(lon0,lat,lon,
                 x, y);  
}  
void Reverse(struct geo_transverse_mercator *pTransverseMercator, double lon0, double x, double y,
                 double& lat, double& lon)  
{  
    pTransverseMercator->GeographicLib::TransverseMercator.Reverse(lon0,x,y,
                 lat, lon);  
}    

#ifdef __cplusplus  
};  
#endif  