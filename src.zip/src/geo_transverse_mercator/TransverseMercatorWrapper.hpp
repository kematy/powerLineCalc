
#ifndef _TRANSVERRSEMERCATORWRAPPER_H__  
#define _TRANSVERRSEMERCATORWRAPPER_H__    
struct geo_transverse_mercator;  
#ifdef __cplusplus  
extern "C" {  
#endif  

struct geo_transverse_mercator *GetInstance(double a, double f, double k0);  
void ReleaseInstance(struct geo_transverse_mercator  **ppInstance);  
extern void Forward(struct geo_transverse_mercator  *pTransversMercator,double lon0, double lat, double lon,
                 double& x, double& y );  
extern void Reverse(struct geo_transverse_mercator  *pTransversMercator,double lon0, double x, double y,
                 double& lat, double& lon ); 
#ifdef __cplusplus  
};  
#endif  
#endif  