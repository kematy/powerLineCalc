extern crate lazy_static;
//#![crate_type="cdylib"]

#[allow(non_snake_case, dead_code, non_camel_case_types)]

mod geodesic;
//mod geotm;


//#[macro_use]
//extern crate lazy_static;
//use std::any::Any;
//  lazy_static! {
//     static ref CCLI: String=String::from("2710");
//   }
//#[warn(unused_imports)]
//use std::cmp::Ord;
//use ordered_float::NotNan; 

use std::f64::consts::PI;
use libc::c_char;
//use libc::c_uchar;
use std::ffi::CStr;
use std::str;
//use std::ffi::CString;

use serde_json;
use serde::{Serialize, Deserialize};
use serde_json::Value;
//const CGCS_A:f64=6378137.0;
//const CGCS_F:f64=1.0/298.257222101;
//const CGCS_SCALE_FACTOR:f64=1.0;

const WGS84_A:f64 = 6378137.0;
const WGS84_F:f64 = 1.0/298.257223563;
//const WGS84_B:f64 = 6356752.314;
//const SM_EccSquared:f64 = 6.69437999013e-03;
const UTM_SCALE_FACTOR:f64 = 0.9996;


#[repr(C)]
pub struct CCdr{
	name: *const libc::c_char,
	al_nnd: *const libc::c_char,
	st_nnd: *const libc::c_char,
	area_al: libc::c_double,
	area_st: libc::c_double,
	area: libc::c_double,
	diameter: libc::c_double,
	linear_co: libc::c_double,
	elastic_modulus: libc::c_double,
	rts: libc::c_double,
	weight: libc::c_double,
}
#[repr(C)]
pub struct CCdrs{
    cdr:  CCdr,
	gw:  CCdr,
	opgw: CCdr,
}
#[derive(Serialize, Deserialize, Debug)]
pub struct Cdr{
	name: String,
	al_nnd: String,
	st_nnd: String,
	area_al: f64,
	area_st: f64,
	area: f64,
	diameter: f64,
	linear_co: f64,
	elastic_modulus: f64,
	rts: f64,
	weight: f64,
}

#[repr(C)]
#[derive(Serialize, Deserialize,Copy,Clone,Debug)]
pub struct Contr_Str{
  fm_max:f32,
  gkm: &'static str,
}
#[repr(C)]
#[derive(Serialize, Deserialize,Copy,Clone,Debug)]
//气象条件：0:覆冰，1：基本风，2：低温，3：年平，4：安装，5：高温，6：操作过电压，7：雷电过电压（有风），8：雷电无风，9：带电作业，10：线温，11:断线，12：验算覆冰
 pub struct Qx {
 	
	hc:f64,
    co:f64,
    max_wind:f64,
    qxdh: &'static str,
    icing: [f64;3],
    wind: [f64;3],
    low_tempr: [f64;3],
    ave_tempr: [f64;3],
    stringing: [f64;3],
    high_tempr: [f64;3],
    switching: [f64;3],
    lightning: [f64;3],
    lightning_no_wind: [f64;3],
    livework: [f64;3],
    cdr_tempr: [f64;3],
    broken: [f64;3],
    checking: [f64;3],
     
}
#[repr(C)]
pub struct CQx {
    qxdh:*const libc::c_char,
    hc:f64,
    co:f64,
    max_wind:f64,
    icing: [f64;3],
    wind: [f64;3],
    low_tempr: [f64;3],
    ave_tempr: [f64;3],
    stringing: [f64;3],
    high_tempr: [f64;3],
    switching: [f64;3],
    lightning: [f64;3],
    lightning_no_wind: [f64;3],
    livework: [f64;3],
    cdr_tempr: [f64;3],
    broken: [f64;3],
    checking: [f64;3],
     
}

type Callback=extern "C" fn(x:f64)->f64;

#[no_mangle]
extern "C" fn rootsec(x1:f64,x2:f64,eps:f64,f:Callback)->f64
{

  let mut f_low:f64=f(x1);
  let mut fs:f64=f(x2);
  let mut rts:f64;
  let mut x_low:f64;
  let mut dx:f64;
  if f_low.abs()<fs.abs() 
   {
   	rts=x1;
    x_low=x2;
    let tmp=f_low;
    f_low=fs;
    fs=tmp;
   } 
  else
   {
   	x_low=x1;
    rts=x2;
   } 
  
  
  for _j in 0..31
  {
  	dx=(x_low-rts)*fs/(fs-f_low);
    x_low=rts;
    f_low=fs;
    rts+=dx;
    fs=f(rts);
    if dx.abs()<eps || fs==0.0
     {
     	println!("rootsec:times={}", _j+1);
        return rts;
     } 
  } 
      10000000000000.0
} 
#[no_mangle]
extern "C" fn root_Aitken(x:f64,interation:usize,eps:f64,f:Callback)->f64
{

    let mut flag:i32;
    let mut  k:usize;

    let mut u:f64;
    let mut  v:f64;
    let mut x0:f64;
      k = 0 as usize; 
      x0 = x; 
      flag = 0;
      while (flag==0) && (k!=interation)
      { 
          k = k + 1; 
          u = f(x0); 
          v = f(u);
         if (u-v).abs()<eps
         { 
            x0 = v; 
            flag = 1; 
         }
          else 
          {
            x0 = v-(v-u)*(v-u)/(v-2.0*u+x0);
          }
        
      }
 
    

  k=interation-k;
  if k==0 
  { 
    return 10000000000000.0;
  } 
  else
  {
    return x0;
  } 
  
}

//static EPS=3.0e-8;
#[no_mangle]
extern "C" fn zbrent(x1:f64,x2:f64,tol:f64,f:Callback)->f64
{
  let (mut a,mut b,mut c)=(x1,x2,x2);
  let mut fa=f(a);
  let mut fb=f(b);
  
  if (fa>0.0 && fb>0.0) || (fa<0.0 && fb<0.0)
  {
  	println!("Root must be bracketed in zbrent");
  	return 10000000000000.0;
  }   
   
   let mut fc=fb;
   let mut d:f64=0.0;
   let mut e:f64=0.0;
   for _j in 1..=100
   {
   	if (fb>0.0 && fc>0.0) || (fb<0.0 && fc<0.0)
    {
       c=a;
       fc=fa;
       d=b-a;
       e=d;	
    }  
    
     if fc.abs()<fb.abs()
     {
       a=b;
       b=c;
       c=a;
       fa=fb;
       fb=fc;
       fc=fa;
     }  
   
     let  tol_one:f64=2.0*3.0e-8*b.abs()+0.5*tol;
     //##puts "tol_one="+tol_one.to_s
     let  xm:f64=0.5*(c-b);
     
     
     if xm.abs()<=tol_one || fb==0.0
     {
     	 println!("zbrent:times={}", _j+1);  
     	 return b;
     }  //puts "times="+j.to_s
      
     //##puts e
     if e==0.0 
      {
      	e=xm;
      } //puts "nil,."
       
     //###########################################
     if e.abs()>=tol_one && fa.abs()>fb.abs()
     {
     	 let  s:f64=fb/fa;    
         let mut p:f64;
         let mut q:f64;
         let  r:f64;
       if a==c
       {
       	 p=2.0*xm*s;
         q=1.0-s;
       } 
       else
       {
       	 q=fa/fc;
         r=fb/fc;
         p=s*(2.0*xm*q*(q-r)-(b-a)*(r-1.0));
         q=(q-1.0)*(r-1.0)*(s-1.0);
       }
         
    
       
        if p>0.0  
        {
        	q=-q;
        }  
        
        
        p=p.abs();
        let min_one:f64=3.0*xm*q-tol_one*q;
        let min_two:f64=(e*q).abs();
        let  min:f64;
        if min_one <min_two
         {
         	 min=min_one;
         }else {
         		min=min_two;
         	}

        if 2.0*p < min
        {
          e=d;
          d=p/q;
        } 
        else                    
        {
          d=xm;
          e=d;
        } 
        
      }  
     else 
     {
       d=xm;
       e=d;
     }  

      //###########################################
       a=b;
       fa=fb;
       
      if d.abs()>tol_one
       {b+=d;
       } 
      else
       {b+=sign(tol_one,xm);
       } 
      
      
      fb=f(b);
   }
     
  0.0
}


fn sign(z:f64,p:f64)->f64
{
	if z*p>0.0
	 {
	 	z.abs()
	 }
	 else {
	 	-1.0*z.abs()
	 }
}  


#[no_mangle]

extern "C" fn  koljgq(n:i32,span:f32,h:f32,a:f32,em:f32,s_weight_1:f32,s_weight_2:f32,s_length_1:f32,s_length_2:f32,gama_x:f32, a_a:[f32;100], q_q:[f32;100], nq:i32, calmode:i32)->f32  //arr: &mut [[f64;6];3]
{
//Dim span1, ls0
//Dim bb
//Dim cos_b
//Dim gamaB        ###分布在斜档距上的比载。
//Dim w1           ###水平投影比载，N/mm2/m
//Dim gamaS        ###绝缘子串折算到总截面A上的比载，N/mm2/m

    //n:i32,span:f32,h:f32,a:f32,em:f32,s_weight_1:f32,s_weight_2:f32,ls:f32,gs:f32,
    let bb:f32 = (h / (1.0*span)).atan();
    let cos_b:f32 = bb.cos();
    let gama_b:f32 = gama_x / cos_b;
    
    let ls:f32;
    let gs:f32;
    if s_weight_1*s_weight_2==0.0 || s_length_1*s_length_2==0.0
    {
      if s_length_1>s_length_2
      {
        ls=s_length_1;
      }else {
        ls=s_length_2;
      }
    }else
    {
      ls=(s_length_1+s_length_2)/2.0;
    }
    let ls0:f32 = ls * cos_b;

    if s_weight_1*s_weight_2==0.0
    {
      if s_weight_1>s_weight_2
      {
          gs=s_weight_1;
      }else {
          gs=s_weight_2;
      }
    }else {
      gs=(s_weight_1+s_weight_2)/2.0;
    }
    

//puts cos_b
//puts ls0
   //let mut h=[0.0;100];
    let mut a_aa:[f32;100]=[0.0;100];
    let mut q_qq:[f32;100]=[0.0;100];
    let mut b_bb:[f32;100]=[0.0;100];
    for index in 0..(nq as usize)
    {
      q_qq[index] = q_q[index]*1.0/(n as f32);
    }
    

    if a_a[0] == 0.0|| q_q[0] == 0.0 || nq==0
     {
      a_aa[0] = span / 2.0;
      q_qq[0] = 0.0;
     } 

     for index in 0..(nq as usize)
    {
      b_bb[index] = span-a_a[index];
      q_qq[index]=q_q[index]/a;
    }
      let span1:f32;
    if nq == 0 && calmode == 0 
    {
      span1 = span - ls0
    }
    else{
      span1 = span - 2.0 * ls0
    }

    let w1:f32 = gama_x * span1 / cos_b;                  //单位截面上的荷载
    
    //let mut gama_s:f32=gama_x;
    //if gs*1.0 / a / ls <gama_x 
    //{
    //  gama_s = gama_x;
    //}
    //else{
    //  gama_s = gs*1.0 / a / ls;                     //绝缘子串比载。
    //}

    let c_m:f32 = (gama_x*gama_x) * em * (cos_b.powf(3.0)) / 24.0;
    let c_n:f32  = (span1) * (span1 + 3.0*ls0); // (1.0*span) ;         //##################span1 * (span1 + 3 * ls0)
    let c_n1:f32  = (span1) * (span1 + 6.0*ls0); // (1.0*span) ;        //##################span1 * (span1 + 6 * ls0),span1.powf(2.0)修改后为span1
    let c_o:f32  = 12.0*gs*ls0/a/gama_b/w1;     //#6*...->12*
    let c_p:f32  = 12.0/w1/gama_b ;                      //##################### 12 / w1 / gamaB

    let c_q:f32 = w1 + 2.0*gs/3.0/a;
    let c_s:f32 = 3.0*(ls0.powf(2.0))*((w1+gs/a).powf(2.0))/w1/gama_b/(1.0*span);       //##3 * ls0 ** 2 * (w1 + gs / a) ** 2 / w1 / gamaB / span,2012-2-26

        let mut  sig_q:f32 = 0.0;
        let mut  sig_qab_g:f32 = 0.0;
        let mut  qa_sig_qb:f32 = 0.0;
        let mut  temp1:f32 = 0.0  ;           //##和值，q_qq[j] * b_bb[j]
        let mut sig_qa:f32=0.0;
 
         if nq == 1  //##############################################
         {
           sig_q = q_qq[0];
           sig_qa=q_qq[0]*a_aa[0];
           sig_qab_g = q_qq[0]*a_aa[0]*b_bb[0]*(gama_b+q_qq[0]/(1.0*span));   //#####span->span1
           qa_sig_qb = 0.0;                   //#####################################################???
         }
         else if nq == 2 {
           sig_q = q_qq[0]+q_qq[1];
           sig_qa=q_qq[0]*a_aa[0]+q_qq[1]*a_aa[1];
           sig_qab_g = q_qq[0]*a_aa[0]*b_bb[0]*(gama_b+q_qq[0]/(1.0*span))+q_qq[1]*a_aa[1]*b_bb[1]*(gama_b+q_qq[1]/(1.0*span));
           qa_sig_qb = q_qq[0]*a_aa[0]*q_qq[1]*b_bb[1];
         }
        else if  nq > 2
         {
              for i in 0..(nq as usize)
              {

                 sig_q+= q_qq[i];
                 sig_qa+=q_qq[i]*a_aa[i];
                 sig_qab_g+= q_qq[i]*a_aa[i]*b_bb[i]*(gama_b+q_qq[i]/(1.0*span));
                for j in (i+1)..(nq as usize)
                {
                  temp1+= q_qq[j]*b_bb[j];
                }
                         
                qa_sig_qb+=q_qq[i]*a_aa[i]*temp1;
              }
                    
               
         }
 
        let mut k:f32=0.0;

        if nq==0 && calmode==0    //###施工时，一侧有绝缘子
        {
          k = c_m*(c_n+0.5*c_o*c_q-c_s);
        }
        //puts "k=c_m * (c_n + 0.5 * co * c_q - c_s)=#{c_m} * (#{c_n} + #{0.5 * co }*#{ c_q} - #{c_s})"
        else if nq==0 && calmode==1    //###竣工时，两侧有绝缘子
         {
           k=c_m*(c_n1+12.0*ls0/a/gama_b/w1*(w1*(s_weight_1+s_weight_2)/2.0+(s_weight_1.powf(2.0)+s_weight_2.powf(2.0))/3.0/a-ls0*1.0/span*(s_weight_1-s_weight_2).powf(2.0)/4.0/a))
   
         }
          //k = c_m*(c_n1+co*c_q)
       else if nq>=1 && calmode== 1 
       {
                                              //###竣工时，两侧有绝缘子，有集中荷载时。
          //k = c_m*(c_n1+c_p*(co/c_p*(c_q+sig_q)+sig_qab_g+2.0/(1.0*span)* qa_sig_qb))
           k = c_m*(c_n1+c_p*(ls0*(w1*(s_weight_1+s_weight_2)/2.0/a+(s_weight_1.powf(2.0)+s_weight_2.powf(2.0))/3.0/a/a+
           s_weight_1/a*sig_q-ls0/span*(s_weight_1-s_weight_2)/2.0/a*(2.0*sig_qa+ls0*(s_weight_1-s_weight_2)/2.0/a))+
           sig_qab_g+2.0/(1.0*span)* qa_sig_qb));
       }


        else if nq>=1 &&  calmode== 0
         {
          k = c_m*(c_n+0.5*c_p*(c_o/c_p*(c_q+sig_q)+sig_qab_g+2.0/(1.0*span)*qa_sig_qb)-c_s);
         } 
        return k;
 }
#[no_mangle]
extern "C" fn  fm_gld(n:i32,span:f32,h:f32,a:f32,em:f32,s_weight_1:f32,s_weight_2:f32,s_length_1:f32,s_length_2:f32,linear_co:f32,gama_m:f32,sigma_m:f32,t_m:f32)->f32
 {
  //n:i32,span:f32,h:f32,a:f32,em:f32,s_weight_1:f32,s_weight_2:f32,ls:f32,gs:f32,gama_x:f32, a_a:[f32;100], q_q:[f32;100], nq:i32, calmode:i32
   return koljgq(n,span,h,a,em,s_weight_1,s_weight_2,s_length_1,s_length_2,gama_m,[0.0;100],[0.0;100],0,1)/sigma_m.powf(2.0)-sigma_m-linear_co*1e-6*em*t_m*(h/span).atan().cos()
 }   

  #[no_mangle]
  extern "C" fn  fm_gld_e(n:i32,span:f32,h:f32,a:f32,em:f32,s_weight_1:f32,s_weight_2:f32,s_length_1:f32,s_length_2:f32,linear_co:f32,gama_m:f32,sigma_m:f32,t_m:f32)->f32
 {
  //n:i32,span:f32,h:f32,a:f32,em:f32,s_weight_1:f32,s_weight_2:f32,ls:f32,gs:f32,gama_x:f32, a_a:[f32;100], q_q:[f32;100], nq:i32, calmode:i32
   return koljgq(n,span,h,a,em,s_weight_1,s_weight_2,s_length_1,s_length_2,gama_m,[0.0;100],[0.0;100],0,0)/sigma_m.powf(2.0)-sigma_m-linear_co*1e-6*em*t_m*(h/span).atan().cos()
 }   


#[no_mangle]
extern "C" fn  sag_x(n:i32,s_weight_1:f32,s_weight_2:f32,s_length_1:f32,s_length_2:f32,span:f32,h:f32,area:f32,sig0:f32, x:f32, gama_x:f32, a_a:[f32;100], q_q:[f32;100], nq:i32, calmode:i32)
-> f32 {

 let cal_mode:i32;
if (s_weight_1*s_weight_2==0.0) || (s_length_1*s_length_2==0.0)
 {
  cal_mode=0;
 } else {
   cal_mode=calmode;
 }


//####
let lj:f32;
let gs:f32;
    if s_weight_1*s_weight_2==0.0 || s_length_1*s_length_2==0.0
    {
      if s_length_1>s_length_2
      {
        lj=s_length_1;
      }else {
        lj=s_length_2;
      }
    }else
    {
      lj=(s_length_1+s_length_2)/2.0;
    }
    

    if s_weight_1*s_weight_2==0.0
    {
      if s_weight_1>s_weight_2
      {
          gs=s_weight_1;
      }else {
          gs=s_weight_2;
      }
    }else {
      gs=(s_weight_1+s_weight_2)/2.0;
    }

let bb:f32 = (h / span).atan();
let cos_b:f32 = bb.cos();
let lj0:f32 = lj * cos_b;

if (span == 0.0) || (gama_x == 0.0) || (sig0 == 0.0)
{
panic!( "Span,Specific_load or stress are zero!");
}    

    let mut a_aa:[f32;100]=[0.0;100];
    let mut q_qq:[f32;100]=[0.0;100];
    let mut b_bb:[f32;100]=[0.0;100];
    for index in 0..(nq as usize)
    {
      q_qq[index] = q_q[index]*1.0/(n as f32);
    }
    

    if a_a[0] == 0.0|| q_q[0] == 0.0 || nq==0
     {
      a_aa[0] = span / 2.0;
      q_qq[0] = 0.0;
     } 

     for index in 0..(nq as usize)
    {
      b_bb[index] = span-a_a[index];
      q_qq[index]=q_q[index]/area;
    }
      let span1:f32;
    if nq == 0 && cal_mode == 0 
    {
      span1 = span - lj0;
    }
    else{
      span1 = span - 2.0 * lj0;
    }

    let _w1:f32 = gama_x * span1 / cos_b;                  //单位截面上的荷载

    let gama_s:f32 = gs*1.0 / area / lj;           //##绝缘子串比载
    let gama_s_1:f32;
    let gama_s_2:f32;
if s_weight_1>0.0 && s_weight_2==0.0
{
    gama_s_1 = s_weight_1*1.0 / area / lj; 
    gama_s_2=0.0;
}

else if s_weight_1==0.0 && s_weight_2>0.0
{
  gama_s_1=0.0;
  gama_s_2 = s_weight_2*1.0 / area / lj;
}
  
else
{
  gama_s_1 = s_weight_1*1.0 / area / lj;
  gama_s_2 = s_weight_2*1.0 / area / lj;
}
  

//####################################################################################
let mut c_t:f32=0.0;
//let mut c_u:f32=0.0;
//let mut c_v:f32=0.0;
let c_x:f32;

if sig0 > 0.0
{
  c_t = 1.0 / sig0 / cos_b;
}

//c_u = gama_x * span.powf(2.0) / 8.0;
//c_v = (gama_s - gama_x) / 2.0 * lj0.powf(2.0);

c_x = gama_x * x * (span - x) / 2.0;

if x < lj0 && x > span - lj0 
{
  panic!("x location out of range!" ); 
}
   
//#fxtemp1=0
//#fxtemp2=0
let mut sig_q_a:f32 = 0.0;
let mut sig_qx_a:f32  = 0.0;
let mut sig_q_b:f32  = 0.0;
let f_0:f32;
let f_1:f32;
let f_tmp:f32;
let mut fx:f32=0.0;
if gama_s_1>0.0
{
  f_0=c_t*c_x*(1.0+lj.powf(2.0)*cos_b.powf(2.0)*(gama_s-gama_x)/gama_x/(1.0*span*x));
}

else
{
  f_0=c_t*c_x*(1.0+lj.powf(2.0)*cos_b.powf(2.0)*(gama_s-gama_x)/gama_x/(1.0*span*(span-x)));
}

//f_1=cT * (cX + cV)   ####两侧有绝缘子；无集中荷载,计算竣工任意点x处弧垂fx；公式？？？
                     //###按手册公式：Fx = cT * (cX + cV )

f_1=c_t*(c_x +(gama_s_1-gama_x)/2.0*(lj0.powf(2.0))-(gama_s_1-gama_s_2)/2.0/span*(lj0.powf(2.0))*x);

if cal_mode==0 
{
  f_tmp=f_0;
}
else
{
  f_tmp=f_1;
}
    
  if nq == 0           //####一侧有绝缘子；无集中荷载,计算施工时任意点x处弧垂fx；从低悬挂点起算。
  /*=begin
   fxtemp1 = cT * (cX + cV * x / span)                      #####耐张串在高悬挂点时，x从低悬挂点起算，施工弧垂
   fxtemp2 = cT * (cX + cV * (span - x) / span)        #####耐张串在低悬挂点，x从低悬挂点起算，施工弧垂
      
      if fxtemp1 < fxtemp2 then
       fx = fxtemp2
       else
       fx = fxtemp1
      end
  =end*/
   {
    fx=f_tmp;
   }
  else if nq == 1  
  {
/*    #cT = 1.0 / sig0 / cos_b
    #cU = gama_x * span ** 2 / 8.0
    #cV = (gamaS - gama_x) / 2.0 * lj0 ** 2
    #cX = gama_x * x * (span - x) / 2.0*/

    if x <= a_aa[0]
    {
      fx = f_tmp + 1.0*x*q_qq[0]* b_bb[0]/sig0/span;
    }
       
       //###MsgBox fx & "," & cT * (cX + cV)
    else
    {
      fx = f_tmp+1.0* (span-x) * q_qq[0] * a_aa[0] / sig0 / span;
    }
       
   } 
  else if nq == 1  //两侧有绝缘子；1集中荷载,计算竣工 任意点x处弧垂fx；
  {
    if x <= a_aa[0] 
    {
      fx = f_tmp + 1.0*x * q_qq[0]* b_bb[0]/ sig0 / span;
    }
       
       //###MsgBox fx & "," & cT * (cX + cV)
    else
    {
      fx = f_tmp +1.0* (span - x) * q_qq[0] * a_aa[0] / sig0 / span;

    }
  }     
  else if nq == 2           //####两侧有绝缘子；2集中荷载,计算竣工 任意点x处弧垂fx；
  {
    if x <= a_aa[0] 
    {
      fx = f_tmp +1.0* x * (q_qq[0] * b_bb[0] + q_qq[1] * b_bb[1]) / sig0 / span;
    }
    else if x <= a_aa[1] && x > a_aa[0] 
    {
      fx = f_tmp + (1.0*x * (q_qq[0] * b_bb[0]+ q_qq[1]* b_bb[1]) - span * q_qq[0] * (x - a_aa[0])) / sig0 / span;
    }
    else
    {
       fx = f_tmp + 1.0*(span - x) * (q_qq[0] * a_aa[0]+ q_qq[1] * a_aa[1]) / sig0 / span;
    }
  }  
  else if nq >= 3          //####两侧有绝缘子；3个以上集中荷载,计算竣工 任意点x处弧垂fx；
 {
   for i in 0..(nq as usize)
   {
     sig_q_a = sig_q_a + q_qq[i] * a_aa[i];
     sig_q_b = sig_q_b + q_qq[i] * b_bb[i];

      if i < (nq - 1 ) as usize
      {
        sig_qx_a = sig_qx_a + q_qq[i] * (x - a_aa[i]);
      }
      else
      {
        sig_qx_a = 0.0;
      }      
   }    
   //############################判断x的区间。
      if x <= a_aa[0] 
      {
        fx = f_tmp + 1.0*x * sig_q_b / sig0 / span;
      }

      else if x <= span - lj0 && x > a_aa[(nq - 1) as usize]
      {
        fx = f_tmp +1.0*(span - x) * sig_q_a / sig0 / span;
      }

      else
      {
        for i in 0..((nq-1)as usize)
         {
          if x > a_aa[i] && x <= a_aa[i + 1] 
           {
            fx = f_tmp + 1.0*(x * sig_q_b - span * sig_qx_a) / sig0 / span;
           }       
         }       
      }         
  }    


    
   return fx
}

//fm_gld(s_weight_1:f32,s_weight_2:f32,s_length_1:f32,s_length_2:f32,,gama_m:f32,sigma_m:f32,t_m:f32)
#[no_mangle]
extern "C" fn gld_fm_max(n:i32,span:f32,h:f32,a:f32,em:f32,linear_co:f32,s_ice_co:f32,s_weight_1:f32,s_weight_2:f32,s_length_1:f32,s_length_2:f32,deta_l:f32,az_wj:f32,gama:[f32;5],qxt:[f32;5],sigma_max:f32,sigma_av:f32,calmode:i32,a_a:[f32;100], q_q:[f32;100],nq:i32,kzs:&mut Contr_Str)-> *const c_char  //##calmode==1 竣工 shi aA=[],qQ=[],nq=0
 { 

      let mut tmp_fm_mode:i32=calmode;

      if s_weight_1*s_weight_2==0.0 || s_length_1*s_length_2==0.0 //#按连续档距计算。
      {
         if calmode==1 || calmode==3
         {
           tmp_fm_mode=calmode-1;
         }
      }
      let cos_b:f32=(h/span).cos();
      let  sigma_max_av:[f32;5]=[sigma_max,sigma_max,sigma_max,sigma_av,sigma_max];
      let mut fm_lst:[f32;5]=[0.0;5];
      let mut  kice:f32;
      let mut q_qq:[f32;100]=[0.0;100];
      
      for i in 0..4
      {
               if i==0
               {
                 kice=s_ice_co;                                
               }else {
                 kice=1.0;
               }
               for index in 0..100
               {
                 if i==0
                 {
                   q_qq[index]=kice*q_q[0];
                 }else
                  {
                     q_qq[index]=q_q[i];
                  }
               }

              if tmp_fm_mode==1
              {
                fm_lst[i]=fm_gld(n,span,h,a,em,s_weight_1,s_weight_2,s_length_1,s_length_2,linear_co,gama[i], sigma_max_av[i], qxt[i]);
              }
                  
              else if tmp_fm_mode==0
              {
                fm_lst[i]=fm_gld_e(n,span,h,a,em,s_weight_1,s_weight_2,s_length_1,s_length_2,linear_co,gama[i], sigma_max_av[i], qxt[i]);
              }
                           
              else if tmp_fm_mode==2
              {
                fm_lst[i]=koljgq(n,span,h,a,em,s_weight_1,s_weight_2,s_length_1,s_length_2,gama[i],a_a,q_qq,nq,0)/sigma_max_av[i].powf(2.0)-sigma_max_av[i]-linear_co*1.0e-6*em*qxt[i]*cos_b;
              }    
              else if tmp_fm_mode==3
              {
                fm_lst[i]=koljgq(n,span,h,a,em,s_weight_1,s_weight_2,s_length_1,s_length_2,gama[i],a_a,q_qq,nq,1)/sigma_max_av[i].powf(2.0)-sigma_max_av[i]-linear_co*1.0e-6*em*qxt[i]*cos_b;           
              }
      }             
              
              
            
      let s_length:f32;
      if s_length_1*s_length_2==0.0
      {
        if s_length_1>s_length_2
        {
          s_length=s_length_1;
        }
        else {
          s_length=s_length_2;
        }
      }else {
        s_length=(s_length_1+s_length_2)*0.5;
      }
      if tmp_fm_mode==1  //##两侧有绝缘子，也按一侧有绝缘子计算，因为两侧有绝缘子对于安装工况没有意义。
       {
        fm_lst[4]=fm_gld_e(n,span,h,a,em,s_weight_1,s_weight_2,s_length_1,s_length_2,linear_co,gama[4], sigma_max_av[4], qxt[4])-em*deta_l*cos_b.powf(2.0)/(span-2.0*s_length*cos_b);    //#安装过牵引detaL（-值）,两端有绝缘子串的线长系数。施工温度ts,无风时;
       }     
       else if tmp_fm_mode==0 //##一侧有绝缘子
       {
         fm_lst[4]=fm_gld_e(n,span,h,a,em,s_weight_1,s_weight_2,s_length_1,s_length_2,linear_co,gama[4], sigma_max_av[4], qxt[4]-az_wj)-em*deta_l*cos_b.powf(2.0)*1.0/(span-2.0*s_length*cos_b);    //#安装过牵引detaL（-值）,两端有绝缘子串的线长系数。施工温度ts,无风
       }        
       else if tmp_fm_mode==2  //##一侧有绝缘子
       {
        fm_lst[4]=koljgq(n,span,h,a,em,s_weight_1,s_weight_2,s_length_1,s_length_2,gama[4],a_a,q_q,nq,tmp_fm_mode-2)/sigma_max_av[4].powf(2.0)-sigma_max_av[4]-linear_co*1.0e-6*em*(qxt[4]-az_wj)*cos_b-em*deta_l*cos_b.powf(2.0)*1.0/(span-1.0*s_length*cos_b);
       } 
       else if tmp_fm_mode==3  //##两侧有绝缘子，也按一侧有绝缘子计算，因为两侧有绝缘子对于安装工况没有意义。
       {
        fm_lst[4]=koljgq(n,span,h,a,em,s_weight_1,s_weight_2,s_length_1,s_length_2,gama[4],a_a,q_q,nq,tmp_fm_mode-3)/sigma_max_av[4].powf(2.0)-sigma_max_av[4]-linear_co*1.0e-6*em*(qxt[4]-az_wj)*cos_b-em*deta_l*cos_b.powf(2.0)*1.0/(span-2.0*s_length*cos_b);
       }         
       
       let str:String;
       let fm_max:f32;
       
       if gama[0]>gama[3] 
       {
        
        //fm_max =fm_lst.iter().max_by(|o, p| o.total_cmp(p));
        //fm_max=fm_lst.iter().copied().max();
        fm_max = fm_lst.iter().copied().fold(f32::NAN, f32::max);
        if fm_max==fm_lst[0]
        {
          str="覆冰".to_string();
        }else if fm_max==fm_lst[1]
        {
          str="大风".to_string();
        }else if  fm_max==fm_lst[2]
        {
          str="低温".to_string();
        }else if  fm_max==fm_lst[3]
        {
          str="年平均气温".to_string();
        }else  if  fm_max==fm_lst[4]
        {
          str="架线过牵引".to_string();
        }else {
         str="未知工况".to_string();
        }
       } else
       {
         let part = &fm_lst[1..5];
         fm_max = part.iter().copied().fold(f32::NAN, f32::max);

        if fm_max==fm_lst[1]
        {
          str="大风".to_string();
        }else if  fm_max==fm_lst[2]
        {
          str="低温".to_string();
        }else if  fm_max==fm_lst[3]
        {
          str="年平均气温".to_string();
        }else  if  fm_max==fm_lst[4]
        {
          str="架线过牵引".to_string();
        }else {
         str="未知工况".to_string();
        }


       }
            

  kzs.fm_max=fm_max;
  kzs.gkm=string_to_static_str(str);
  return convert(kzs.gkm.to_string())
}

#[no_mangle]
extern "C" fn gld_sag_max(span:f32,h:f32,area:f32,s_weight_1:f32,s_weight_2:f32,s_length_1:f32,s_length_2:f32,lj:f32,sig0:f32, gama_x:f32,  calmode:i32)
->f32 {
//
    let bb:f32 = (h / (1.0*span)).atan();
    let cos_b:f32 = bb.cos();
    let lj0:f32=lj*cos_b;

    let cal_mode:i32;
    if s_weight_1*s_weight_2==0.0 || s_length_1*s_length_2==0.0
     {
      cal_mode=0;
     }
     else {
       cal_mode=calmode;
     }

      if span == 0.0 || gama_x == 0.0 || sig0 ==0.0 
      {
        panic!("span,gama_x or sig0 are zero!Please check parameters!");
      }
      let gama_s:f32;
     if s_weight_1>s_weight_2
     {
      gama_s= s_weight_1*1.0 / area / lj;           //##绝缘子串比载
    }else {
      gama_s= s_weight_2*1.0 / area / lj;
    }
      

     let gama_s_1:f32 = s_weight_1*1.0 / area / lj; 
     let gama_s_2:f32 = s_weight_2*1.0 / area / lj; 
      
      let c_t:f32;
      let c_u:f32;
      let c_v:f32;

      if sig0 > 0.0 
      {
        c_t = 1.0 / sig0 / cos_b;
      }else {
        c_t = 0.0;
      }
      
      c_u = gama_x * span.powf(2.0) / 8.0;
      c_v = (gama_s - gama_x) / 2.0 * lj0.powf(2.0);
      let xm_0:f32;
      let xm_1:f32;
      if gama_s_1>0.0
      {
         xm_0=span/2.0-(gama_s-gama_x)*(lj0.powf(2.0))/(2.0*gama_x*span);
       }else{
        
         xm_0=span/2.0+(gama_s-gama_x)*(lj0.powf(2.0))/(2.0*gama_x*span);
       }
       
       if  s_weight_1*s_weight_2==0.0 || s_length_1*s_length_2==0.0
        {
          xm_1=xm_0;
        }else{
          xm_1=span/2.0-(gama_s_1-gama_s_2)*(lj0.powf(2.0))/(2.0*gama_x*span);
        }
               

        let c_v_1:f32 = (gama_s_1-gama_x)/2.0*lj0.powf(2.0)-(gama_s_1-gama_s_2)/2.0*(lj0.powf(2.0))*xm_1/span;
      //#cX = gama_x * x * (span - x) / 2.0

      if  cal_mode == 0                  //###施工观测弧垂
      {
        return c_t * (c_u + c_v * 0.5 + 0.5 * c_v.powf(2.0) / gama_x / span.powf(2.0));
      }else {
        return c_t * (c_u + c_v_1);
      }
        
 }



#[no_mangle]
extern "C" fn ridders(x1:f64,x2:f64,eps:f64,f:Callback)->f64
{
  let mut f_low=f(x1);
  let mut f_high=f(x2);
  let mut x_low:f64;
  let mut x_high:f64;
  let mut ans:f64;
if (f_low>0.0 && f_high<0.0) || (f_low<0.0 && f_high>0.0)
 {   
 	x_low=x1;
    x_high=x2;
    ans=-1.11e30;  
  

  for _j in 0..=40
  {
    let xm:f64=0.5*(x_low+x_high);  
    let fm=f(xm) ;
    let s=(fm*fm-f_low*f_high).sqrt();
    if s==0.0
    {
    	return 10000000000000.0;
    }  
     let xnew:f64;
    if f_low>=f_high
    {
     xnew=xm+(xm-x_low)*1.0*fm/s;
    } else 
    {
    	xnew=xm-(xm-x_low)*1.0*fm/s;
    }
      if (xnew-ans).abs()<=eps 
       {
       	//puts "times="+j.to_s
       	return ans;
       } 
        
      
      ans=xnew;
      let fnew:f64=f(ans); 
      if fnew==0.0
      {
      	 return ans;
      } 
      
    
      if sign(fm,fnew)!=fm
      {
      	 x_low=xm;
         f_low=fm;
         x_high=ans;
         f_high=fnew;
      }   
      else if sign(f_low,fnew)!=f_low
      {
      	 x_high=ans;
         f_high=fnew;
      }  
      else if sign(f_high,fnew)!=f_high 
      {
      	 x_low=ans;
         f_low=fnew;
      }  
      else
      { 
       return 10000000000000.0;
      }
      
      
      if (x_high-x_low).abs()<=eps
       // puts "times="+j.to_s
      {
      	return ans;
      }  
      else
        {
        	println!("ridders:times={},solve->{}",_j+1,ans); 
        }  
      
   }
}   
else
{
   if f_low==0.0
   {
   	return x1;
   } 
  
  
   if f_high==0.0
    {
    	return x2;
    }
    
  
  println!("error:root must be bracketed in zriddr"); 
  return 10000000000000.0;
}  
  10000000000000.0
}
#[no_mangle]
extern "C" fn rtdeadpoint(x0:f64,tol:f64,f:Callback) -> f64 
{
 let mut x1:f64=x0;
 let mut x:f64;
 for j in 0..300
 {
   x=f(x1);
   if (x-x1).abs()<tol
   {
   	 println!("rtdeadpoint:times={}",j+1);
     return x;
   }  
   else
   {
   	x1=x; 
    if j>=300-1
    {
      println!("rtdeadpoint:times={},x={}",j+1,x);
      return 10000000000000.0;
    }
       
   }  
     
 }
 10000000000000.0
}
#[no_mangle]
extern "C" fn rootbis(x1:f64,x2:f64,tol:f64,f:Callback)->f64
{

let  fs=f(x1);
let mut fmid=f(x2);
let mut dx:f64;
let mut rtb:f64;
if fs*fmid>=0.0
{
	return 10000000000000.0;
}

if fs<0.0
{
  dx=x2-x1; 
  rtb=x1;
} 
else
{
	dx=x1-x2; 
    rtb=x2;
}   



for j in 0..40
{  dx*=0.5;
  let xmid:f64=rtb+dx;
  fmid=f(xmid);
  
  if fmid<=0.0
  {
  	rtb=xmid;
  }  
  
  if dx.abs()<tol || fmid==0.0
  {
  	 
  	 println!("rootbis:times={}", j+1);
    return rtb;
  } 
  
}
10000000000000.0
}
#[no_mangle]
extern "C" fn rootflsp(x1:f64,x2:f64,eps:f64,f:Callback)->f64
{

  let mut f_low=f(x1);
  let mut f_high=f(x2);
  let mut x_low:f64;
  let mut x_high:f64;
  
  if f_low*f_high>0.0 
  {
	return 10000000000000.0;
  }
  
  if f_low<0.0
  {
    x_low=x1;
    x_high=x2;
  } 
  else
  {
    x_low=x2;
    x_high=x1;
    let tmp=f_low;
    f_low=f_high;
    f_high=tmp;
  }  
   
  let mut dx:f64=x_high-x_low;
  let mut rtf:f64;
  let mut del:f64;
  let mut fs:f64;
  for j in 0..200
  {
    rtf=x_low+dx*f_low/(f_low-f_high);
    fs=f(rtf);
    
    if fs<0.0 
    {
     del=rtf-x_low;
     x_low=rtf;
     f_low=fs;	
    }
    else
    {
      del=x_high-rtf;
      x_high=rtf;
      f_high=fs;   
    }  

    dx=x_high-x_low;
    if del.abs()<eps || fs==0.0
    {
    	println!("rootflsp:times={}",j+1 );
    	return rtf;
    }  
    
  }
  10000000000000.0
}
#[no_mangle]
extern "C" fn golden(mut x1:f64,mut x2:f64,tol:f64,f:Callback,res:&mut [f64;2])->bool
{
   let r=0.61803399;
   let c:f64=1.0-r;
   let mut ax:f64=x1+(x2-x1)*c;
   let mut bx:f64=x1+(x2-x1)*r;
   
   
   let mut fa=f(ax);
   let mut fb=f(bx);
   let mut count=0;
   while  (bx-ax).abs()>tol 
   {
      count+=1;
     if fb>fa
     {
   	   x2=bx;
     }  
     else
     {
   	   x1=ax;
     }  
  
     ax=x1+(x2-x1)*c;
     bx=x1+(x2-x1)*r;
   
     fa=f(ax);
     fb=f(bx);
   }
   
     
     println!("golden:times={}", count);
     if fa<fb
     {
     	*res=[ax,fa];
     }  
    else
    {
    	*res=[bx,fb];
    }   
    true    
}

#[no_mangle]
extern "C" fn golden2( ax:f64, bx:f64, cx:f64,tol:f64,f:Callback,res:&mut [f64;2])->bool
{
   let r=0.61803399;
   let c:f64=1.0-r;
   let mut x0=ax;
   let mut x3=cx;
   let mut x1:f64;
   let mut x2:f64;
   if (cx-bx).abs()>(bx-ax).abs()          
   {
   	 x1=bx;                                   
     x2=bx+c*(cx-bx);   
   }                  
   else
   {
   	 x2=bx;
     x1=bx-c*(bx-ax);  
   }
     
     
     let mut f1=f(x1);
     let mut f2=f(x2);
     let mut count=0;
     while  (x3-x0).abs() > tol*(x1.abs()+x2.abs())
     {  if f2<f1
        {
         x0=x1;
         x1=x2;
         x2=r*x1+c*x3;
         f1=f2;
         f2=f(x2);
        } 
       else
       {
       	 x3=x2;
         x2=x1;
         x1=r*x2+c*x0;
         f2=f1;
         f1=f(x1);
        
       }
         
       count+=1;
     }
     
     println!("goden2:times={}",count );
     if f1<f2
     {
     	*res= [x1,f1];
     }  
     else
     {
     	*res= [x2,f2];
     }  
   true
}

#[no_mangle]
extern "C" fn brent_golden( ax:f64, bx:f64, cx:f64,tol:f64,f:Callback,res:&mut [f64;2])->bool
{
   //let r=0.61803399;
   //let c:f64=1.0-r;
   let it_max:i32=100;
   let c_gold:f64=0.381960;
   let z_eps:f64=1.0e-10;

  let mut e:f64=0.0;
  let mut a:f64;
  let mut b:f64;
  let mut d:f64;
  let mut u:f64;
  let mut x=bx;
  let mut w=bx;
  let mut v=bx;
  let mut fx=f(x);
  let mut fv=fx;
  let mut fw=fv;
  if ax<cx
  {
   a=ax;
  }else {
   a=cx;
  }
   if ax>cx
  {
   b=ax;
  }else {
   b=cx;
  }

  d=b-a;
  
  
  for j in 1..=it_max
  {

    let xm:f64=0.5*(a+b);
    let tol_1:f64=tol*x.abs()+z_eps;
    let tol_2:f64=2.0*tol_1;
    
    if (x-xm).abs()<=tol_2-0.5*(b-a)
    {
    	*res=[x,fx];
    	println!("brent_golden:times={}", j);
    	return true;
    }
     
    if e.abs()>tol_1             
     {

       let r:f64=(x-w)*(fx-fv);
       let mut q:f64=(x-v)*(fx-fw);
       let mut p:f64=(x-v)*q-(x-w)*r;
       q=2.0*(q-r);
       if q>0.0
        {p=-p;} 
       
       q=q.abs();
       let etemp=e;
       e=d;
       if (p.abs()>=(0.5*q*etemp) || p<=q*(a-x) ) || p>=q*(b-x)
       {
       	 if x>=xm
       	 {
       	 	e=a-x;
       	 }else {
       	 	e=b-x;
       	 }
         d=c_gold*e;
       }
       else
       {
       	 d=p/q;
         u=x+d;
         if u-a<tol_2 || b-u < tol_2
         {
         	d=sign(tol_1,xm-x); 
         }               
           
       }  
        
    }
    else
    {
    	if x>=xm
       	 {
       	 	e=a-x;
       	 }else {
       	 	e=b-x;
       	 }
         d=c_gold*e;
     } 
     if d.abs()>tol_1
     {
     	u=x+d;
     } else
     {
     	u=x+sign(tol_1,d);
     }    
 

     let fu=f(u); 
     if fu<=fx       
     {
     	if u>=x 
        {
         a=x;	
        }  
       else
        {
         b=x;	
        }  
         v=w;
         w=x;
         x=u;
         fv=fw;
         fw=fx;
         fx=fu;
     }  
     else
     {
     	if u<x
         {
         	 a=u;
         } 
        else
         {
         	b=u;
         }  
        
        
        if fu<=fw || w==x
        {
          v=w;
          w=u;
          fv=fw;
          fw=fu;
        }  
        else if fu<=fv || v==x || v==w
        {
          v=u;
          fv=fu;
        } 
     
     }   
       
  }
     
  *res=[x,fx];
  true

}

#[no_mangle]
extern "C" fn mnbrak( mut ax:f64, mut bx:f64,glimit:f64,f:Callback,res:&mut [f64;6])->bool
{
   let gold:f64=1.618034;   
   //let :f64=100.0;      
   let tiny:f64=1.0e-20;      

  let mut fa=f(ax);
  let mut fb=f(bx);
  let mut cx:f64; 
  let mut fc:f64;
  if fa>fb
   {
   	let tmp1=ax;
   	ax=bx;
   	bx=tmp1;
    let tmp2=fa;
    fa=fb;
    fb=tmp2;
   } 
  cx=bx+gold*(bx-ax);//c的第一个估值
  
  fc=f(cx);
  let mut u:f64;
  let mut fu:f64;
  let mut ulim:f64;
  while fb>fc            
  {
  	//在界定搜索区间之前，使得程序在此继续返回通过a，b，c的抛物外推计算u；
    //TINY防止被0除。
    let r:f64=(bx-ax)*(fb-fc);
    let q:f64=(bx-cx)*(fb-fa);
    
    if (q-r).abs()>tiny 
    {
    	u=bx-((bx-cx)*q-(bx-ax)*r)/(2.0*sign((q-r).abs(),q-r));
    }else {
    	u=bx-((bx-cx)*q-(bx-ax)*r)/(2.0*sign(tiny,q-r));
    }
    
     ulim=bx+glimit*(cx-bx);
    
    if (bx-u)*(u-cx)>0.0
    {   
        fu=f(u);
        //在b和c之间找到了一个极小点
        if fu<fc   
         {
          ax=bx;
          bx=u;
          fa=fb;
          fb=fu;
          *res= [ax,bx,cx,fa,fb,f(cx)];
          break; 
         }  
         //在a和u之间找到了一个极小点
        else if fu>fb   
        {
          cx=u;
          fc=fu;
          *res= [ax,bx,cx,fa,fb,fc];
          break; 
        }  
        
          u=cx+gold*(cx-bx); 
          fu=f(u);
    }
    else if (cx-u)*(u-ulim)>0.0   
    {
        fu=f(u);
        if fu<fc
        {
        	bx=cx;
        	cx=u;
        	u=cx+gold*(cx-bx);
        	fb=fc;
        	fc=fu;
        	fu=f(u);
        }  
       
    }    
    else if (u-ulim)*(ulim-cx)>=0.0  
     {
     	u=ulim;
        fu=f(u);
     }   
    else                                     
    {
       u=cx+gold*(cx-bx); 
       fu=f(u);
    }   
    ax=bx;
    bx=cx;
    cx=u;
    fa=fb;
    fb=fc;
    fc=fu;
  }   
  true
}

#[no_mangle]
extern "C" fn lagrange_interp_100( x:f64,n:usize, a:&[f64;100], b:&[f64;100])->f64
{
   let mut sum:f64=0.0;

   for i in 0..n
   {
      let mut s=1.0;
      let mut t=1.0;
     for j in 0..n
     {  if j != i
       {
       	 s=s*(x-a[j]);
         t=t*(a[i]-a[j]);
       }  
  
     }
     
    sum=sum+b[i]*s/t;
   }
    sum 
}
#[no_mangle]
extern "C" fn lagrange_interp_1000( x:f64,n:usize, a:&[f64;1000], b:&[f64;1000])->f64
{
   let mut sum:f64=0.0;

   for i in 0..n
   {
      let mut s=1.0;
      let mut t=1.0;
     for j in 0..n
     {  if j != i
       {
       	 s=s*(x-a[j]);
         t=t*(a[i]-a[j]);
       }  
  
     }
     
    sum=sum+b[i]*s/t;
   }
    sum 
}
#[no_mangle]
extern "C" fn lagrange_interp_10000( x:f64,n:usize, a:&[f64;10000], b:&[f64;10000])->f64
{
   let mut sum:f64=0.0;

   for i in 0..n
   {
      let mut s=1.0;
      let mut t=1.0;
     for j in 0..n
     {  if j != i
       {
       	 s=s*(x-a[j]);
         t=t*(a[i]-a[j]);
       }  
  
     }
     
    sum=sum+b[i]*s/t;
   }
    sum 
}


#[no_mangle]
extern "C" fn inlagrn_100( t:f64,n:usize, x:&[f64;100], y:&[f64;100])->f64
{

   let mut z:f64=0.0;
   let zero:usize=0;
   let one:usize=1;
   let two:usize=2;
   if n==one
   {
   	z=y[0];
     return z;
   }  
   
   if n==two
   {
   	z=(y[0]*(t-x[1])-y[1]*(t-x[0]))/(x[0]-x[1]);
     return z;
   }  

   let mut i:usize=0;
   while x[i]<t && i<n
    {
    	i=i+1;
    }  
 
    let  k:usize;
    
    if i-4<zero
    {
    	k=0;
    }
    else {
    	k=i-4;
    }
    
    let mut m:usize=i+3;
    if m>n-1
    {
     m=n-1;
    }
    for _i in k..=m
    { 
    	let mut s:f64=1.0;
    	for _j in k..=m
       {
    	   if _j!=_i
            {
            s=s*(t-x[_j])/(x[_i]-x[_j]);	
            }  
           
       }  
 

       z=z+s*y[_i]

   }
  return z;
}
#[no_mangle]
extern "C" fn inlagrn_three_100( t:f64,n:usize, x:&[f64;100], y:&[f64;100])->f64
{
	
   let mut z:f64=0.0;
   //let zero:usize=0;
   let one:usize=1;
   let two:usize=2;
   if n<one
    {
    	return z;
    } 
   
   if n==one
    {
      z=y[0];
     return z;
    } 
   
   if n==two
   {
   	z=(y[0]*(t-x[1])-y[1]*(t-x[0]))/(x[0]-x[1]);
     return z;
   }  
  let mut k:usize;
  let mut m:usize;
   if t<=x[1]
   {
 	k=0;
    m=2;
   } 
   else
   {
   	if t>=x[n-2]
    {
      k=n-3;
      m=n-1;
    }  
    else
    {    
    	k=1;
        m=n;
        while (m-k)!=one  
        {  
          let i:usize=(k+m)/2;      
          if t<x[i-1]       
          {
          	m=i;
          }  
          else
          {
          	k=i;
          }  
        }
        k=k-1;
        m=m-1;
          if (t-x[k]).abs()<(t-x[m]).abs()
           {
           	k=k-1;
           } 
          else
          {
          	m=m+1;
          }  
          
    }
   }
    
      
      z=0.0;
      for _i in k..=m
      {  let mut s:f64=1.0;
        for _j in k..=m
        {
        	 if _j!=_i
           {
           	s*=(t-x[_j])/(x[_i]-x[_j]);
           } 
        } 
        
        z+=s*y[_i];
       
      }
      z
}
#[no_mangle]
extern "C" fn chasing_100( n:usize, a:&[f64;100], b:&[f64;100], c:&[f64;100], d:&[f64;100],x: &mut [f64;100])->bool
{
//追赶法求三对角矩阵
	
    let mut b_tmp=[0.0;100];
    let mut a_tmp=[0.0;100];

    b_tmp[0]=b[0];
    a_tmp[0]=0.0;
    for i in 1..n
    {
    	a_tmp[i]=a[i]*1.0/b_tmp[i-1];
       b_tmp[i]=b[i]-a_tmp[i]*c[i-1];
    }
    let mut d_tmp=[0.0;100];
    
    d_tmp[0]=d[0];
    for i in 1..n
    {
    	d_tmp[i]=d[i]-a_tmp[i]*d_tmp[i-1];
    }
     
    x[n-1]=d_tmp[n-1]*1.0/b_tmp[n-1];
    for i in (0..(n-1)).rev()
    {
    	x[i]=(d_tmp[i]-c[i]*x[i+1])*1.0/b_tmp[i];
    }
   true
}
#[no_mangle]
extern "C" fn chasing_1000( n:usize, a:&[f64;1000], b:&[f64;1000], c:&[f64;1000], d:&[f64;1000],x: &mut [f64;1000])->bool
{
//追赶法求三对角矩阵
	
    let mut b_tmp=[0.0;1000];
    let mut a_tmp=[0.0;1000];

    b_tmp[0]=b[0];
    a_tmp[0]=0.0;
    for i in 1..n
    {
    	a_tmp[i]=a[i]*1.0/b_tmp[i-1];
       b_tmp[i]=b[i]-a_tmp[i]*c[i-1];
    }
    let mut d_tmp=[0.0;1000];
    
    d_tmp[0]=d[0];
    for i in 1..n
    {
    	d_tmp[i]=d[i]-a_tmp[i]*d_tmp[i-1];
    }
     
    x[n-1]=d_tmp[n-1]*1.0/b_tmp[n-1];
    for i in (0..(n-1)).rev()
    {
    	x[i]=(d_tmp[i]-c[i]*x[i+1])*1.0/b_tmp[i];
    }
   true
}
#[no_mangle]
extern "C" fn chasing_10000( n:usize, a:&[f64;10000], b:&[f64;10000], c:&[f64;10000], d:&[f64;10000],x: &mut [f64;10000])->bool
{
//追赶法求三对角矩阵
	
    let mut b_tmp=[0.0;10000];
    let mut a_tmp=[0.0;10000];

    b_tmp[0]=b[0];
    a_tmp[0]=0.0;
    for i in 1..n
    {
    	a_tmp[i]=a[i]*1.0/b_tmp[i-1];
       b_tmp[i]=b[i]-a_tmp[i]*c[i-1];
    }
    let mut d_tmp=[0.0;10000];
    
    d_tmp[0]=d[0];
    for i in 1..n
    {
    	d_tmp[i]=d[i]-a_tmp[i]*d_tmp[i-1];
    }
     
    x[n-1]=d_tmp[n-1]*1.0/b_tmp[n-1];
    for i in (0..(n-1)).rev()
    {
    	x[i]=(d_tmp[i]-c[i]*x[i+1])*1.0/b_tmp[i];
    }
   true
}
#[no_mangle]
extern "C" fn m_calc_100( n:usize,ff0:f64,ffn:f64, x_lst:&[f64;100],y_lst:&[f64;100], m: &mut [f64;100])->bool
{
	//def mcalc(ptlst,ff0=0,ffn=0)

   let mut h=[0.0;100];
   let mut fs=[0.0;100];
   for j in 0..(n-1)
   {
   	  h[j]=x_lst[j+1]-x_lst[j];
      fs[j]=(y_lst[j+1]-y_lst[j])*1.0/h[j];
   }
   let mut npd=[0.0;100];
   let mut miu=[0.0;100];
   
   let  b=[2.0;100];
   
   npd[0]=0.0;
   miu[0]=1.0;
   for j in 1..(n-1)
   {
   	 npd[j]=h[j]*1.0/(h[j-1]+h[j]);
     miu[j]=h[j-1]*1.0/(h[j-1]+h[j]);
   }
    npd[n-1]=1.0;
    miu[n-1]=0.0;
    let mut g=[0.0;100];
   for j in 1..(n-1)
   {
   	g[j]=3.0*(npd[j]*fs[j-1]+miu[j]*fs[j])
   }
   
   //自然边界条件，
    //g[0]=3.0*f[0]-h[0]/2.0*ff0  
    //g[n-1]=3.0*f[n-2]+h[n-2]/2.0*ffn
    g[0]=3.0/h[0]*(y_lst[1]-y_lst[0])-h[0]/2.0*ff0; 
    g[n-1]=3.0/h[n-2]*(y_lst[n-1]-y_lst[n-2])+h[n-2]/2.0*ffn;

   chasing_100(n,&npd,&b,&miu,&g,m)
}
#[no_mangle]
extern "C" fn m_calc_1000( n:usize,ff0:f64,ffn:f64, x_lst:&[f64;1000],y_lst:&[f64;1000], m: &mut [f64;1000])->bool
{
	//def mcalc(ptlst,ff0=0,ffn=0)

   let mut h=[0.0;1000];
   let mut fs=[0.0;1000];
   for j in 0..(n-1)
   {
   	  h[j]=x_lst[j+1]-x_lst[j];
      fs[j]=(y_lst[j+1]-y_lst[j])*1.0/h[j];
   }
   let mut npd=[0.0;1000];
   let mut miu=[0.0;1000];
   
   let  b=[2.0;1000];
   
   npd[0]=0.0;
   miu[0]=1.0;
   for j in 1..(n-1)
   {
   	 npd[j]=h[j]*1.0/(h[j-1]+h[j]);
     miu[j]=h[j-1]*1.0/(h[j-1]+h[j]);
   }
    npd[n-1]=1.0;
    miu[n-1]=0.0;
    let mut g=[0.0;1000];
   for j in 1..(n-1)
   {
   	g[j]=3.0*(npd[j]*fs[j-1]+miu[j]*fs[j])
   }
   
   //自然边界条件，
    //g[0]=3.0*f[0]-h[0]/2.0*ff0  
    //g[n-1]=3.0*f[n-2]+h[n-2]/2.0*ffn
    g[0]=3.0/h[0]*(y_lst[1]-y_lst[0])-h[0]/2.0*ff0; 
    g[n-1]=3.0/h[n-2]*(y_lst[n-1]-y_lst[n-2])+h[n-2]/2.0*ffn;

   chasing_1000(n,&npd,&b,&miu,&g,m)
}
#[no_mangle]
extern "C" fn m_calc_10000( n:usize,ff0:f64,ffn:f64, x_lst:&[f64;10000],y_lst:&[f64;10000], m: &mut [f64;10000])->bool
{
	//def mcalc(ptlst,ff0=0,ffn=0)

   let mut h=[0.0;10000];
   let mut fs=[0.0;10000];
   for j in 0..(n-1)
   {
   	  h[j]=x_lst[j+1]-x_lst[j];
      fs[j]=(y_lst[j+1]-y_lst[j])*1.0/h[j];
   }
   let mut npd=[0.0;10000];
   let mut miu=[0.0;10000];
   
   let  b=[2.0;10000];
   
   npd[0]=0.0;
   miu[0]=1.0;
   for j in 1..(n-1)
   {
   	 npd[j]=h[j]*1.0/(h[j-1]+h[j]);
     miu[j]=h[j-1]*1.0/(h[j-1]+h[j]);
   }
    npd[n-1]=1.0;
    miu[n-1]=0.0;
    let mut g=[0.0;10000];
   for j in 1..(n-1)
   {
   	g[j]=3.0*(npd[j]*fs[j-1]+miu[j]*fs[j])
   }
   
   //自然边界条件，
    //g[0]=3.0*f[0]-h[0]/2.0*ff0  
    //g[n-1]=3.0*f[n-2]+h[n-2]/2.0*ffn
    g[0]=3.0/h[0]*(y_lst[1]-y_lst[0])-h[0]/2.0*ff0; 
    g[n-1]=3.0/h[n-2]*(y_lst[n-1]-y_lst[n-2])+h[n-2]/2.0*ffn;

   chasing_10000(n,&npd,&b,&miu,&g,m)
}

#[no_mangle]
extern "C" fn cubic_sp_interpo_10000( n_x_:usize,n_x_lst:usize,m:&[f64;10000], x_:&[f64;10000],y_:&[f64;10000], x_lst: &[f64;10000],y_lst: &mut [f64;10000])->bool
{
  //for x in x_lst
  for i in 0..n_x_lst
   {
   	 let x=x_lst[i];
   	 let mut tmp_j:usize=0;
     let mut alpha_j:f64=0.0;
     let mut alpha_j_1:f64=0.0;
     let mut beta_j:f64=0.0;
     let mut beta_j_1:f64=0.0;
     for j in 0..n_x_
     {
     	let orx=x_[j];
     	
     	if j<n_x_-1
        {
        	if x>=orx && x<=x_[j+1]
            {
              alpha_j=((x-x_[j+1])/(orx-x_[j+1])).powf(2.0)*(1.0+2.0*(x-orx)*1.0/(x_[j+1]-orx));
              alpha_j_1=((x-x_[j])/(x_[j+1]-orx)).powf(2.0)*(1.0+2.0*(x-x_[j+1])*1.0/(orx-x_[j+1]));

              beta_j=((x-x_[j+1])/(orx-x_[j+1])).powf(2.0)*(x-orx);
              beta_j_1=((x-x_[j])/(x_[j+1]-orx)).powf(2.0)*(x-x_[j+1]);
              tmp_j=j;
              break;

            } 
          else
          {
          	continue;
          }	
         
        }  
     }
     
     let y:f64=y_[tmp_j]*alpha_j + y_[tmp_j+1]*alpha_j_1 + m[tmp_j]*beta_j + m[tmp_j+1]*beta_j_1;
     y_lst[i]=y;
  
   }
     true
}
#[no_mangle]
extern "C" fn interpo2d_100(n:usize,m:usize,u:f32,v:f32,x:&[f32;100],y:&[f32;100],z:&[[f32;100];100])->f32
{
	
	let mut ip:usize;
	let mut ipp:usize;
	let mut i:usize;
	let mut j:usize;
	let mut l:usize;
	let mut iq:usize;
	let mut iqq:usize;
	//let  k:usize=0;

    let mut h:f32;
    let mut w:f32;
	let mut b=[0.0;100];

	 //n =  x.size()  	//给定结点X方向上的坐标个数
	 //m =  y.size()   	//给定结点Y方向上的坐标个数

	if u<=x[0]
	{
		ip = 1;
		ipp = 4;
	}	
    else if u>=x[n-1]
	{
		ip = n - 3;
		ipp = n;
	}	
    else
	{
		i = 1;
		j = n;
        
		while ((i - j) != 1) && (( j-i ) != 1)
		{
			l = (i + j) / 2;
            
			if u < x[l - 1]
			{
				j = l;
			}	
            else 
            {
            	i = l;
            }
		}	
           
		ip = i - 3;
		ipp = i + 4;
	}	
    
	if ip < 1
	{
		ip = 1;
	}

    if ipp > n 
    {
    	ipp = n; 
    }

    if v <= y[0]
     {
     	iq = 1;
		iqq = 4;
     }
    else if v >= y[m - 1]
    {
    	iq = m - 3;
		iqq = m;
    }
    else
    {
    	i = 1;
		j =m;
        
		while ((i - j) != 1) && (( j-i ) != 1)
		{
			l = (i + j) / 2;
            //v < y [l-1]
			if v <y[l - 1]
            {
				j = l;
            }
            else 
             {
             	i = l;
             }
		}

		iq = i - 3;
		iqq = i + 4;
    }

	if iq < 1
    {
		iq = 1; 
    }

    if iqq > m
    {
    	iqq = m; 
    }
    
	for i in (ip - 1)..ipp    //###col x 
	{	
		b[i -ip + 1] = 0.0;
        
		for j in (iq - 1)..iqq   //###row y 
		{

			//#puts '-'*50
			//#puts i,j，反了
			h= z[i][j];
            
			for k in (iq - 1)..iqq
			{
				if k != j
                {
					h = h * (v - y[k]) / (y[j] - y[k]);
                }
			}
			
			b[i- ip + 1] = b[i - ip + 1] + h;
		}
	}
    
	w = 0.0;
    
	for i in (ip - 1)..ipp   
	{
		h= b[i-ip+1];
		for j in (ip - 1)..ipp
		{
			if j != i
            {
				h = h * (u - x[j]) / (x[i] - x[j]);
            }
		}	
		w =w + h;
	}	

    
	w
}
#[no_mangle]
extern "C" fn interpo2d(n:usize,m:usize,u:f32,v:f32,x:&[f32;10000],y:&[f32;10000],z:&[[f32;10000];10000])->f32
{
	
	let mut ip:usize;
	let mut ipp:usize;
	let mut i:usize;
	let mut j:usize;
	let mut l:usize;
	let mut iq:usize;
	let mut iqq:usize;
	//let  k:usize=0;

    let mut h:f32;
    let mut w:f32;
	let mut b=[0.0;10000];

	 //n =  x.size()  	//给定结点X方向上的坐标个数
	 //m =  y.size()   	//给定结点Y方向上的坐标个数

	if u<=x[0]
	{
		ip = 1;
		ipp = 4;
	}	
    else if u>=x[n-1]
	{
		ip = n - 3;
		ipp = n;
	}	
    else
	{
		i = 1;
		j = n;
        
		while ((i - j) != 1) && (( j-i ) != 1)
		{
			l = (i + j) / 2;
            
			if u < x[l - 1]
			{
				j = l;
			}	
            else 
            {
            	i = l;
            }
		}	
           
		ip = i - 3;
		ipp = i + 4;
	}	
    
	if ip < 1
	{
		ip = 1;
	}

    if ipp > n 
    {
    	ipp = n; 
    }

    if v <= y[0]
     {
     	iq = 1;
		iqq = 4;
     }
    else if v >= y[m - 1]
    {
    	iq = m - 3;
		iqq = m;
    }
    else
    {
    	i = 1;
		j =m;
        
		while ((i - j) != 1) && (( j-i ) != 1)
		{
			l = (i + j) / 2;
            //v < y [l-1]
			if v <y[l - 1]
            {
				j = l;
            }
            else 
             {
             	i = l;
             }
		}

		iq = i - 3;
		iqq = i + 4;
    }

	if iq < 1
    {
		iq = 1; 
    }

    if iqq > m
    {
    	iqq = m; 
    }
    
	for i in (ip - 1)..ipp    //###col x 
	{	
		b[i -ip + 1] = 0.0;
        
		for j in (iq - 1)..iqq   //###row y 
		{

			//#puts '-'*50
			//#puts i,j，反了
			h= z[i][j];
            
			for k in (iq - 1)..iqq
			{
				if k != j
                {
					h = h * (v - y[k]) / (y[j] - y[k]);
                }
			}
			
			b[i- ip + 1] = b[i - ip + 1] + h;
		}
	}
    
	w = 0.0;
    
	for i in (ip - 1)..ipp   
	{
		h= b[i-ip+1];
		for j in (ip - 1)..ipp
		{
			if j != i
            {
				h = h * (u - x[j]) / (x[i] - x[j]);
            }
		}	
		w =w + h;
	}	

    
	w
}

//最小二乘法拟合多项式，int m = a.size();	//拟合多项式的项数，即拟合多项式的最高次数为m-1
//要求m<=n且m<=20。若m>n或m>20，本函数自动按m=min{n,20}处理。
//a,m-1次多项式系数,dt 0-误差平方和，1-误差绝对值之和，2-误差绝对值的最大值
#[no_mangle]
extern "C" fn fit_curve_least_squares_m(n:usize,mut m:usize,x:&[f64;201],y:&[f64;201],a:&mut [f64;20],dt:&mut [f64;3])->bool
{
	//最小二乘曲线拟合 

	//int i,j,k;
    let mut g:f64;
    let mut q:f64=0.0;
    let mut d2:f64;
    let mut s=[0.0;20];
    let mut t=[0.0;20];
    let mut b=[0.0;20];
	//int n = x.size();				//给定数据点的个数

	//int m = a.size();	//拟合多项式的项数，即拟合多项式的最高次数为m-1
	//要求m<=n且m<=20。若m>n或m>20，本函数自动按m=min{n,20}处理。

    for i in 0..m
     {
    	a[i]=0.0;
    }

    if m>n  
    {
    	m = n;
    }
    if m>20 
    {
    	m=20;
    }
    let mut z:f64=0.0;
    let mut p:f64=0.0;
    let mut c:f64=0.0;
    for i in 0..n 
    {
    	z = z + x[i] / (n as f64);//x_av
    }
    

    b[0]=1.0;
	let mut d1 = n as f64;//d0
    for ix in 0..n
    { 
		p=p+(x[ix]-z);
		c=c+y[ix];}//
	
		c=c/d1; //c0
		p=p/d1;//alpha
		a[0]=c*b[0];
	   if m>1
	   {
			t[1]=1.0;
			t[0]=-p;
			d2=0.0;
			c=0.0; 
			g=0.0;
        for i in 0..n
        { 
			q=x[i]-z-p; //x-x_ave-alpha
			d2=d2+q*q;//dj
            c=c+y[i]*q;
            g=g+(x[i]-z)*q*q;
		}
        c=c/d2;//c
		p=g/d2;//alpha
		q=d2/d1;//beta=q
        d1=d2;
        a[1]=c*t[1]; 
		a[0]=c*t[0]+a[0];
       }
     //}//
    for j in 2..m
    { 
		s[j]=t[j-1];
        s[j-1]=-p*t[j-1]+t[j-2];//-alhpa*t(j-1)+t(j-2)
        if j>=3
        {
          for k in (1..=(j-2)).rev()	
          {
          	s[k]=-p*t[k]+t[k-1]-q*b[k];//q=beta
          }
        }
        s[0]=-p*t[0]-q*b[0];
        d2=0.0;
		c=0.0;
		g=0.0;
        for i in 0..n
        { 
			q=s[j];//Q（x）,
            for k in (0..=(j-1)).rev()	
            {
            	q=q*(x[i]-z)+s[k];
            }

            d2=d2+q*q; //dj
            c=c+y[i]*q;
            g=g+(x[i]-z)*q*q;
        }
        c=c/d2; //c
		p=g/d2; //alpha
		q=d2/d1;//beta
        d1=d2;
        a[j]=c*s[j]; 
        t[j]=s[j];
        for k in (0..=(j-1)).rev()
        {
			a[k]=c*s[k]+a[k];
            b[k]=t[k]; 
            t[k]=s[k];
        }
    }
    dt[0]=0.0;
	dt[1]=0.0;
	dt[2]=0.0;
    for i in 0..n
    { 
		q=a[m-1];
        for k in (0..=(m-2)).rev()
        {
        	q=a[k]+q*(x[i]-z);
        }	
        p=q-y[i];
        if p.abs()>dt[2]
        {
        	dt[2]=p.abs();
        } 
        dt[0]=dt[0]+p*p;
        dt[1]=dt[1]+p.abs();
    }
    true
}
	//切比雪夫曲线拟合,最佳拟合多项式，给定点的偏差最大值为最小
	//int n = x.size();	//给定数据点的个数
	//int m = a.size()-1;	//拟合多项式的项数，即拟合多项式的最高次数为m-1
	//要求m<n且m<=20。若m>=n或m>20，本函数自动按m=min{n-1,20}处理。
#[no_mangle]
extern "C" fn fit_curve_chebyshev_m(n:usize,mut m:usize,x:&[f64;201],y:&[f64;201],a:&mut [f64;20])->bool
{
	
	//int ii,k,im,ix[21];
	let mut ii:usize;
	//let k:usize;
	let mut im:usize;
	let mut ix=[0 as usize;21];

    let mut h=[0.0;21];
    let mut y1:f64;
    let mut y2:f64;
    let mut h1:f64;
    let mut h2:f64;
    let mut d:f64;
    let mut hm:f64;


    for i in 0..m
    {
      a[i]=0.0;	
    }
    

    if m>=n 
     {
     m=n-1;
     }

    if m>=20
    {
    	m=19;
    }
    
    let   m1:usize = m + 1;
    let mut ha:f64=0.0;
    ix[0] = 0; 
	ix[m] = n - 1;
    let  mut l:usize = (n - 1) / m; 
	let mut j:usize = l;
    for i in 1..m
    {
		ix[i]=j;
		j=j+l;
	}
	let bl=true;
    while bl==true
    {
		let mut hh=1.0;
        for i in 0..=m
        {
			a[i]=y[ix[i]];
			h[i]=-hh;
			hh=-hh;
		}
        for j in 1..=m
        {
			ii=m1;
			y2=a[ii-1]; 
			h2=h[ii-1];
            for i in j..=m
            {
				d=x[ix[ii-1]]-x[ix[m1-i-1]];
                y1=a[m-i+j-1];
                h1=h[m-i+j-1];
                a[ii-1]=(y2-y1)/d;
                h[ii-1]=(h2-h1)/d;
                ii=m-i+j;
				y2=y1;
				h2=h1;
            }
        }
        hh=-a[m]/h[m];
        for i in 0..=m 
        {
        	a[i]=a[i]+h[i]*hh;
        }
        for j in 1..m
        {
			ii=m-j;
			d=x[ix[ii-1]];
            y2=a[ii-1];
            for k in (m1-j)..=m
            {
				y1=a[k-1];
				a[ii-1]=y2-d*y1;
                y2=y1; 
				ii=k;
            }
        }
        hm = hh.abs();
        if hm <= ha 
		{
			a[m] = -hm;
			return true;
		}
        a[m]=hm; 
		ha=hm; 
		im=ix[0]; 
		h1=hh;
        j=0;
        for i in 0..n
        {
			if i==ix[j]
            { 
				if j<m 
                {
                	j=j+1;
                }
				

			}
			else
			{ 
				h2=a[m-1];
				for k in (0..=(m-2)).rev()
				{
					h2=h2*x[i]+a[k];
				}	
				

				h2=h2-y[i];
				if h2.abs()>hm
				{
					hm=h2.abs(); 
					h1=h2;
					im=i;
				}
			}
		}
		if im==ix[0] 
        {
        	return true;
        }
		
		let mut i=0;
		l=1;
		while l==1
		{ 
			l=0;
			if im>=ix[i]
			{
				i=i+1;
				if i<=m
                {
				 l=1;
                }

			}
		}
		if i>m  
        {
        	i=m;
        }
		

		if i==(i/2)*2
        {
        	h2=-hh;
        }
		else 
		{
			h2=hh;
		}
		if h1*h2>=0.0 
		{
		 ix[i]=im;
		}
		else
		{
			if im<ix[0]
			{ 
				for j in (0..=(m-1)).rev()
				{
					ix[j+1]=ix[j];
				}	
				ix[0]=im;
			}
			else
			{
				if im>ix[m]
				{
					for j in 1..=m {
					
						ix[j-1]=ix[j];
					}
					ix[m]=im;
				}
				else 
				{
					ix[i-1]=im;
				}
			}
		}
	}
	false

}
//最佳一致逼近多项式里米兹法
//[a,b]为区间，n为阶数=p.size()-1,int n = p.size()-1;	//n-1次最佳一致逼近多项式的项数
//要求n<=20; 若n>20，函数自动取n=20
#[no_mangle]
extern "C" fn approximation_remez_m(mut n:usize,eps:f64,a:f64,b:f64,f:Callback,p:&mut [f64;21])->bool
{
	

    let mut x=[0.0;21];
    let mut g=[0.0;21];
    let mut t:f64;
    let mut s:f64;
    let mut xx:f64;
    let mut x0:f64;
    let mut h:f64;
    let mut yy:f64;
    let mut k:usize;
    let mut i:usize;
    let mut j:usize;
    if n>20 
    {
    	n=20;
    }
    let m:usize=n+1; 
	let mut d=1.0e+35;
    for k in 0..n
    {
		t = (((n - k) as f64) * PI / (n as f64)).cos();
        x[k] = (b + a + (b-a) * t) / 2.0;
    }
    let bl=true;
    while bl==true
    {
		let mut u=1.0;
        for i in 0..m
        {
			p[i]=f(x[i]);
            g[i]=-u;
			u=-u;
        }
        for j in 0..n
        {
			k=m;
			s=p[k-1];
			xx=g[k-1];
            for i in j..n
            {
				t=p[n-i+j-1];
				x0=g[n-i+j-1];
                p[k-1]=(s-t)/(x[k-1]-x[m-i-2]);
                g[k-1]=(xx-x0)/(x[k-1]-x[m-i-2]);
                k=n-i+j;
				s=t;
				xx=x0;
            }
        }
        u=-p[m-1]/g[m-1];
        for i in 0..m	
        {
        	p[i]=p[i]+g[i]*u;
        }
        for j in 1..n
        {
			k=n-j; 
			h=x[k-1];
			s=p[k-1];
            for i in (m-j)..=n
            {
				t=p[i-1];
				p[k-1]=s-h*t;
                s=t; 
				k=i;
            }
        }
        p[m-1]=u.abs();
		u=p[m-1];
        if (u-d).abs() <= eps 
        {
        	return  true;
        }
        
        d=u; 
		h=0.1*(b-a)/(1.0*(n as f64));
        xx=a; 
		x0=a;
        while x0<=b
        {
			s=f(x0);
			t=p[n-1];
            for i in (0..=(n-2)).rev()
            {
            	t=t*x0+p[i];	
            }
            s=(s-t).abs();
            if s>u 
			{
				u=s; 
				xx=x0;
			}
            x0=x0+h;
        }
        s=f(xx); 
		t=p[n-1];
        for i in (0..=(n-2)).rev()
        {
           t=t*xx+p[i];
        }	
        yy=s-t; 
		i=1;
		j=n+1;
        while (j-i)!=1
        {
			k=(i+j)/2;
            if xx<x[k-1] 
            {
            	j=k;
            }
            else 
            {
            	i=k;
            }
        }
        if xx<x[0]
        {
			s=f(x[0]); 
			t=p[n-1];
            for k in (0..=(n-2)).rev()
            {
            	t=t*x[0]+p[k];
            }	
            s=s-t;
            if s*yy>0.0
            {
              x[0]=xx;
            } 
            else
            {
				for k in (0..=(n-1)).rev()
				{
					x[k+1]=x[k];
				}	
                x[0]=xx;
            }
        }
        else
        {
			if xx>x[n]
            {
				s=f(x[n]); 
				t=p[n-1];
                for  k in (0..=(n-2)).rev() 
                {
                  t=t*x[n]+p[k];
                }	
                s=s-t;
                if s*yy>0.0 
                {
                	x[n]=xx;
                } 
                else
                {
					for k in 0..n
					{
						x[k]=x[k+1];
					}	
                    x[n]=xx;
                }
            }
            else
            {
				i=i-1;
				j=j-1;
                s=f(x[i]);
				t=p[n-1];
                for k in (0..=(n-2)).rev() 
                {
                	t=t*x[i]+p[k];
                }	
                s=s-t;
                if s*yy>0.0
                {
                	x[i]=xx;
                } 
                else 
                {
                	x[j]=xx;
                }
            }
        }
    } //while
  false
}
//矩形域的最小二乘曲面拟合
//int n = x.size();			//给定数据点的X坐标个数
//int m = y.size();			//给定数据点的Y坐标个数
//int p = a.GetRowNum();		//拟合多项式中变量x的最高次数加1
//并要求p<=n且p<=20; 否则在本函数中自动取p=min{n,20}处理
//int q = a.GetColNum();		//拟合多项式中变量y的最高次数加1
//并要求q<=m且q<=20; 否则在本函数中自动取q=min{m,20}处理
#[no_mangle]
extern "C" fn fit_surface_least_squares_m( n:usize, m:usize,mut p:usize,mut q:usize,x:&[f64;100],y:&[f64;100],z:&[[f64;100];100],a:&mut [[f64;20];20],dt:&mut [f64;3])->bool
{
	
	//let mut l:usize;
	//let mut kk:usize;
    let mut apx=[0.0;20];
    let mut apy=[0.0;20];
    let mut bx=[0.0;20];
    let mut by=[0.0;20];
    let mut t=[0.0;20];
    let mut t1=[0.0;20];
    let mut t2=[0.0;20];
    //let mut d2:f64;
    let mut d=[0.0;2];
    let mut g=[0.0;3];
    //let mut g1:f64;
    //let mut g2:f64;
    let mut x2:f64;
    let mut dd:f64;
    let mut y1:f64;
    let mut x1:f64;
    let mut v=[[0.0;100];20];
    let mut u=[[0.0;20];20];
	//matrix<_Ty> v(20,m), u(20,20);

	//int p = a.GetRowNum();		//拟合多项式中变量x的最高次数加1
	//并要求p<=n且p<=20; 否则在本函数中自动取p=min{n,20}处理

	//int q = a.GetColNum();		//拟合多项式中变量y的最高次数加1
	//并要求q<=m且q<=20; 否则在本函数中自动取q=min{m,20}处理

    for i in 0..p
    {
    	for j in 0..q
    	{
    		a[i][j]=0.0;
    	} 
    }    

    if p>n {p=n;}
    if p>20 {p=20;} 
    if q>m {q=m;}
    if q>20 {q=20;}

    let mut xx:f64=0.0;
    
    
    for i in 0..n 
    {
    	xx+=  x[i] / (n as f64);
    }
    let mut yy:f64=0.0;
    for i in 0..m 
    { 
    	yy+= y[i] / (m as f64);
    } 
    d[0]=n as f64; 
    apx[0]=0.0;
    for i in 0..n 
    {
    	apx[0]+=x[i] - xx;
    }	
    apx[0] = apx[0] / d[0];
    for j in 0..m
    { 
		v[0][j]=0.0;
        for i in 0..n 
        {
        	v[0][j]=v[0][j]+z[i][j];
        }	
        v[0][j]=v[0][j]/d[0];
    }
    if p>1
    { 
		d[1]=0.0;
		apx[1]=0.0;
        for i in 0..n
        {
			g[0]=x[i]-xx-apx[0];
            d[1]+=g[0]*g[0];
            apx[1]+=(x[i]-xx)*g[0]*g[0];
        }
        apx[1]=apx[1]/d[1];
        bx[1]=d[1]/d[0];
        for j in 0..m
        { 
			v[1][j]=0.0;
            for i in 0..n
            {
				g[0]=x[i]-xx-apx[0];
                v[1][j]=v[1][j]+z[i][j]*g[0];
            }
            v[1][j]/=d[1];
        }
        d[0]=d[1];
    }
    for k in 2..p
    { 
		d[1]=0.0; 
		apx[k]=0.0;
        for j in 0..m 
        {
        	v[k][j]=0.0;
        } 
        for i in 0..n
        {
			g[1]=1.0; 
			g[2]=x[i]-xx-apx[0];

            for j in 2..=k
            {
				g[0]=(x[i]-xx-apx[j-1])*g[2]-bx[j-1]*g[1];
                g[1]=g[2]; 
                g[2]=g[0];
            }
            d[1]+=g[0]*g[0];
            apx[k]=apx[k]+(x[i]-xx)*g[0]*g[0];
            for j in 0..m	
            {
            	v[k][j]+=z[i][j]*g[0];
            }
        }
        for j in 0..m 
        {
        	v[k][j]/=d[1];
        }	
        apx[k]=apx[k]/d[1];
        bx[k]=d[1]/d[0];
        d[0]=d[1];
    }
    d[0]=m as f64; 
	apy[0]=0.0;
    for i in 0..m 
    {
    	apy[0]+=y[i]-yy;
    }	
    apy[0]=apy[0]/d[0];
    for j in 0..p
    { 
		u[j][0]=0.0;
        for i in 0..m 
        {
        	u[j][0]+=v[j][i];
        }	
		u[j][0]/=d[0];
    }
    if q>1
    { 
		d[1]=0.0; 
		apy[1]=0.0;
        for i in 0..m
        {
			g[0]=y[i]-yy-apy[0];
            d[1]+=g[0]*g[0];
            apy[1]+=(y[i]-yy)*g[0]*g[0];
        }
        apy[1]=apy[1]/d[1];
        by[1]=d[1]/d[0];
        for j in 0..p
		{
			u[j][1]=0.0;
            for i in 0..m
            {
				g[0]=y[i]-yy-apy[0];
				u[j][1]+=v[j][i]*g[0];
            }
			u[j][1]/=d[1];
        }
        d[0]=d[1];
    }
    for k in 2..q
    { 
		d[1]=0.0;
		apy[k]=0.0;
		for j in 0..p 
		{
			u[j][k]=0.0;
		} 
        for i in 0..m
        {
			g[1]=1.0;
            g[2]=y[i]-yy-apy[0];
            for j in 2..=k
            {
				g[0]=(y[i]-yy-apy[j-1])*g[2]-by[j-1]*g[1];
                g[1]=g[2];
				g[2]=g[0];
            }
            d[1]+=g[0]*g[0];
            apy[k]=apy[k]+(y[i]-yy)*g[0]*g[0];
            for j in 0..p 
            {
            	u[j][k]+=v[j][i]*g[0];
            }	
        }
        for j in 0..p 
        {
        	u[j][k]/=d[1];
        }	
        apy[k]/=d[1];
        by[k]=d[1]/d[0];
        d[0]=d[1];
    }
    v[0][0]=1.0;
	v[1][0]=-apy[0]; 
	v[1][1]=1.0;
    for i in 0..p
    {
      for j in 0..q 
      {
      	a[i][j]=0.0;
      }	
    }

    for i in 2..q
    {
		v[i][i]=v[i-1][i-1];
        v[i][i-1]=-apy[i-1]*v[i-1][i-1]+v[i-1][i-2];
        if i>=3
        {
        	for k in (1..=(i-2)).rev()
        	{
        		v[i][k]=-apy[i-1]*v[i-1][k]+v[i-1][k-1]-by[i-1]*v[i-2][k];
        	}
            
        }
          
        v[i][0]=-apy[i-1]*v[i-1][0]-by[i-1]*v[i-2][0];
    }
    for i in 0..p
    { 
		if i==0
		{
			t[0]=1.0;
			t1[0]=1.0;
		}
        else
        {
			if i==1
            {
				t[0]=-apx[0];
				t[1]=1.0;
                t2[0]=t[0];
				t2[1]=t[1];
            }
            else
            { 
				t[i]=t2[i-1];
                t[i-1]=-apx[i-1]*t2[i-1]+t2[i-2];
                if i>=3
                {
                	for k in (1..=(i-2)).rev()
                	{
                		t[k]=-apx[i-1]*t2[k]+t2[k-1]-bx[i-1]*t1[k];
                         
                	}
                    
                }
                  
                t[0]=-apx[i-1]*t2[0]-bx[i-1]*t1[0];
                t2[i]=t[i];
                for k in (0..=(i-1)).rev()
                { 
					t1[k]=t2[k];
					t2[k]=t[k];
				}
            }
        }
        for j in 0..q
        {
        	for k in (0..=i).rev()
        	{
        		for l in (0..=j).rev()
				{
					a[k][l]+=u[i][j]*t[k]*v[j][l];
				}
        	}
            
        }
          
    }
    for i in 0..3
    {
    	dt[i]=0.0; 
    }
	//计算dt 
    //dt[0]存放拟合多项式与数据点误差的平方和 
    //dt[1]存放拟合多项式与数据点误差的绝对值之和 
    //dt[2]存放拟合多项式与数据点误差绝对值的最大值
    for i in 0..n
    {
		x1=x[i]-xx;
        for j in 0..m
        {
			y1=y[j]-yy;
            x2=1.0; 
			dd=0.0;
            for k in 0..p
            {
				g[0]=a[k][q-1];
                for kk in (0..=(q-2)).rev() 
                {
                	g[0]=g[0]*y1+a[k][kk];
                }	
                g[0]=g[0]*x2;
				dd+=g[0];
				x2*=x1;
            }
            dd-=z[i][j];
            if dd.abs()>dt[2] 
            {
            	dt[2]=dd.abs();
            } 
            dt[0]=dt[0]+dd*dd;
            dt[1]=dt[1]+dd.abs();
        }
    }
  true
}

#[test]
fn test_fslsm() {
	//let x=[0.0;11];
	//let y=[0.0;21];
	//let z=[[21];11];
	//let a=[[0.0;5];6];
	//let mut dt[0.0;3];
     let x=&mut [0.0;100];
     let y=&mut [0.0;100];
     let z=&mut [[0.0;100];100];
     let a=&mut [[0.0;20];20];
     let dt=&mut [0.0;3];
     let _b=[[0.888696,0.096095,-1.38677,0.903053,-0.171411],
[8.59716,0.929614,-13.4154,8.73604,-1.65821],
[-45.7529,-4.94728,71.3951,-46.492,8.82477],
[85.1474,9.20702,-132.868,86.5229,-16.4231],
[-62.8532,-6.79634,98.0792,-63.8686,12.1231],
[16.99,1.83714,-26.5121,17.2645,-3.27702]];
let dtb=[5.80138,25.37615,0.55597];
      for i in 0..=10 {x[i]=0.2*(i as f64);}
      for i in 0..=20 {y[i]=0.1*(i as f64);} 
      for  i in 0..=10 
      {
      	for j in 0..=20
      	{
          z[i][j]=std::f64::consts::E.powf(x[i]*x[i]-y[j]*y[j]);
      	}
      }
      let _bl=fit_surface_least_squares_m( 11, 21,6,5,x,y,z,a,dt);


        for i in 0..3
		  	{
          assert_eq!((dt[i]-dtb[i]).abs()<=0.001,true);
        }
	      

}


#[no_mangle]
extern "C" fn poly_value_two_dims(stx_nno:usize,sty_nno:usize,dx:f64,dy:f64,dcoff:& [[f64;20];20])->f64
{
	
		//dCoff为二维多项式系数数组，dX为自变量x，dY为自变量y
	let mut dvalue = 0.0;
	let mut dtemp = 1.0;
	//二维多项式自变量y的项数，其最高次数为styNo-1
	//二维多项式自变量x的项数，其最高次数为stxNo-1

	for st in 0..stx_nno  //行数
	{
		let mut dus:f64 = dcoff[st][sty_nno-1] * dtemp;
		for sr in (0..=(sty_nno-2)).rev()
		{
			dus = dus * dy + dcoff[st][sr] * dtemp;
		}	
		dvalue = dvalue + dus;
		dtemp = dtemp * dx;
	}
	dvalue		//返回多项式值

}
#[no_mangle]
extern "C" fn bilinear_interpo_m(x:f64,y:f64,x_ary:&[f64;2],y_ary:&[f64;2],z_ary:&mut [[f64;100];100],b:&mut [f64;100])->f64
{
   let mut sxz=0.0;
   let mut syz=0.0;
   let mut sxyz=0.0;
   let mut sz=0.0;
   
   let mut sx=0.0;
   let mut sxx=0.0;
   let mut sxy=0.0;
   let mut sxxy=0.0;

   let mut sy=0.0;
   let mut syy=0.0;
   let mut sxyy=0.0;

   let mut sxxyy=0.0;


   
   
   //let  a:&mut [[f64;100];100];
   //let b=&mut [0.0;100];
   for i in 0..1
   {
   	for j in 0..1
   	{
      sxz+=x_ary[j]*z_ary[i][j];
      syz+=y_ary[i]*z_ary[i][j];
      sxyz+=x_ary[j]*y_ary[i]*z_ary[i][j];
      sz+=z_ary[i][j];
      
      sx+=x_ary[j];
      sxx+=x_ary[j].powf(2.0);
      sxy+=x_ary[j]*y_ary[i];
      sxxy+=x_ary[j].powf(2.0)*y_ary[i];
      sy+=y_ary[i];
      syy+=y_ary[i].powf(2.0);
      sxyy+=x_ary[j]*y_ary[i];
      sxxyy+=x_ary[j].powf(2.0)*y_ary[i].powf(2.0);

   	}
   }
   b[0]=sxz;
   b[1]=syz;
   b[2]=sxyz;
   b[3]=sz;

   z_ary[0][0]=sx;
   z_ary[0][1]=sxx;
   z_ary[0][2]=sxy;
   z_ary[0][3]=sxxy;

   z_ary[1][0]=sy;
   z_ary[1][1]=sxy;
   z_ary[1][2]=syy;
   z_ary[1][3]=sxyy;

   z_ary[2][0]=sxy;
   z_ary[2][1]=sxxy;
   z_ary[2][2]=sxyy;
   z_ary[2][3]=sxxyy;

   z_ary[3][0]=1.0;
   z_ary[3][1]=sx;
   z_ary[3][2]=sy;
   z_ary[3][3]=sxy;
    
    for i in 0..4
    {
    	for j in 0..4
    	{
    		println!("{} ",z_ary[i][j] );
    		//a[i][j]=z_ary[i][j];
    	}
    	println!("\n")
    }

   let bl=le_total_choice_gauss_m(4,z_ary,b);
   let res:f64;
   if bl==true
    {
      res=b[0]+b[1]*x+b[2]*y+b[3]*x*y;
    }
    else {
    	res=9999999999999.0;
    }
   res
}
#[no_mangle]
extern "C" fn le_total_choice_gauss_m(n:usize,a:&mut [[f64;100];100],b:&mut [f64;100])->bool
{

	let mut max_value:f64;//记录主元绝对值
	let mut tmp:f64;
	let mut l:usize=1;
	//let  mut i:usize;
	//let  mut j:usize;
	let mut is:usize=0;		
    let mut yn:bool;
    
	
	let mut js=[0 as usize;100];			//保存换列位置
    
	for k in 0..(n-1)	//全选主元
	{	
		max_value = 0.0;				//给保存主元绝对值变量赋初值
		        
		for i in k..n
		{
			for j in k..n
            {		
				tmp = a[i][j].abs();	//求m(i,j)绝对值
				if tmp > max_value	//发现一个更大的主元
				{ 
					max_value = tmp;	//保存新主元绝对值
					js[k] = j;		//新主元所在列
					is = i;			//新主元所在行
				}
            }
		}		
			
		yn =max_value==0.0;
        if yn==true
        {
        	l = 0;				//主元为0
        } 
		else
		{
			if js[k] != k 			//换列
			{
				for i in 0..n
				{
                    let _tmp=a[i][k];
                    a[i][k]=a[i][js[k]];
                    a[i][js[k]]=_tmp;
				}
			}	
								
			if is != k				//换行
			{ 
				for j in k..n
				{
					let _tmp=a[k][j];
					a[k][j]=a[is][j];
					a[is][j]=_tmp
				}	
                let _tmpb=b[k];//方程组右边第k元素与第is元素交换
                b[k]=b[is];
                b[is]=_tmpb;
					
			}
		}
        
		if l == 0					//矩阵奇异(主元为0)
		{
			println!("le_total_choice_gauss_m:fail 1\n");
            return false;				// 求解失败，返回0值
		}
        
		//max_value =a[k][k].abs();

        for j in (k+1)..n
        {
        	a[k][j]/=a[k][k];
        }	 //max_value;
        
		b[k] /= a[k][k]; //max_value;
        for i in (k+1)..n
		{
			for j in (k+1)..n
			{
                a[i][j]=a[i][j]-a[i][k]*a[k][j];
			}
            
			b[i] = b[i] - a[i][k] * b[k];
		}
	}
    
	max_value = a[n - 1][n - 1].abs();	//主元

	yn = max_value==0.0;
    if yn==true						//主元为0
	{
		println!("le_total_choice_gauss_m:fail 2");
        return false;					//求解失败，返回0值
	}

	b[n - 1] /= a[n - 1][n - 1];//求解方程组右边X的解

    for i in (0..=(n-2)).rev()	//回代过程
	{
		let  mut t = 0.0;
        
		for j in (i+1)..n
		{
			t = t + a[i][j] * b[j];
		}
        
		b[i] = b[i] - t;
	}
    
	js[n - 1] = n - 1;				//X最后一个元素不用换
    for k in (0..=(n-2)).rev()	//k可以从n-2开始
	{
		if js[k] != k				//交换X的元素位置(由全选换列产生的)
		{
			
			let _tmpb=b[k];
			b[k]=b[js[k]];
			b[js[k]]=_tmpb;
              
		}	
	}	
    
	return true;						//方程组求解成功！


}

#[no_mangle]
extern "C" fn bla2xyz(zone_nnumber:i32,lat:f64,lon:f64,alt:f64,res:&mut [f64;3])->bool
{
  let a:f64=6378.137;
  let e:f64=0.0818192;
  let k0:f64=0.9996;
  let _e0:f64=500.0;
  let _nn0:f64=0.0;
  let mut lamda0:f64=((zone_nnumber-1)*6-180+3) as f64;
   lamda0=lamda0*PI/180.0;
  let  phi:f64=lat*PI/180.0;
  let lamda:f64=lon*PI/180.0;
  let v:f64=1.0/(1.0-e.powf(2.0)*(phi.sin()).powf(2.0)).sqrt();
  let _a:f64=(lamda-lamda0)*phi.cos();
  let _t:f64=phi.tan()*phi.tan();
  let _c:f64=e.powf(2.0)*phi.cos()*phi.cos()/(1.0-e.powf(2.0));
  let s:f64=(1.0-e.powf(2.0)/4.0-3.0*e.powf(4.0)/63.0-5.0*e.powf(6.0)/256.0)*phi-
  (3.0*e.powf(2.0)/8.0+3.0*e.powf(4.0)/32.0+45.0*e.powf(6.0)/1024.0)*(2.0*phi).sin()+
  (15.0*e.powf(4.0)/256.0+45.0*e.powf(6.0)/1024.0)*(4.0*phi).sin()-35.0*e.powf(6.0)/3072.0*(6.0*phi).sin();

  res[0]=_e0+k0*a*v*(_a+(1.0-_t-_c)*_a.powf(3.0)/6.0+(5.0-18.0*_t+_t.powf(2.0))*_a.powf(5.0)/120.0);
  res[1]=_nn0+k0*a*(s+v*phi.tan()*(_a.powf(2.0)/2.0+(5.0-_t+9.0*_c+4.0*_c.powf(2.0))*_a.powf(4.0)/24.0+(61.0-58.0*_t+_t.powf(2.0))*_a.powf(6.0)/720.0));
  res[0]=res[0]*1000.0;
  res[1]=res[1]*1000.0;
  res[2]=alt;
  true
}





#[no_mangle]
extern "C" fn r_span(ary:&mut [u32;100],n:usize)->i32
{

  let mut sum3:f64=0.0;
  let mut sum:f64=0.0;
  for i in 0..(n-1)
    {

        sum3+=(ary[i] as f64).powf(3.0);
          sum+=ary[i] as f64;
    }    
    let tmp:f64=sum3/sum;
    tmp.sqrt().round() as i32
  
} 
#[no_mangle]
extern "C" fn sag_h(gama_x:f64,sigma_x:f64,span:f64,h:f64)->f64
{
  let cos_b:f64=span/(h.powf(2.0)+span.powf(2.0)).sqrt();
  gama_x*span.powf(2.0)/8.0/sigma_x/cos_b+gama_x.powf(3.0)*span.powf(4.0)/384.0/sigma_x.powf(3.0)/(cos_b.powf(3.0))
}

#[no_mangle]
extern "C" fn fm(span:f64,gama_m:f64,sigma_m:f64,t_m:f64,linear_co:f64,elastic_modulus:f64)->f64
{
   span.powf(2.0)*gama_m.powf(2.0)*elastic_modulus/24.0/sigma_m.powf(2.0)-sigma_m-linear_co*elastic_modulus*t_m

}
 fn convert(pack_data:String)->*const i8
{
	let ptr:*const u8=(pack_data+"\0").as_ptr();
	let ptr:*const i8=ptr as *const i8;
	//let _s=unsafe{*ptr};
	ptr
}

#[no_mangle]
extern "C" fn cdrs(json:*const c_char,arr: &mut [[f64;6];3],st:&mut CCdrs)-> bool
{
  let c_str: &CStr=unsafe {CStr::from_ptr(json)};
  let str_slice: &str=c_str.to_str().unwrap();
  let mut s:String=str_slice.to_string();

  s=s.replace( "导线", "cdr");
  s=s.replace( "普通地线", "gw");
  s=s.replace( "地线", "gw");
  s=s.replace( "光缆", "opgw");
  s=s.replace( "OPGW", "opgw");
  s=s.replace( "电线型号", "name"); 
  s=s.replace( "铝规格", "al_nnd"); 
  s=s.replace( "钢规格", "st_nnd"); 
  s=s.replace( "铝截面","area_al"); 
  s=s.replace( "钢截面", "area_st"); 
  s=s.replace( "总截面", "area"); 
  s=s.replace( "外径", "diameter"); 
  s=s.replace( "线性系数", "linear_co"); 
  s=s.replace( "弹性模量", "elastic_modulus"); 
  s=s.replace( "拉断力", "rts"); 
  s=s.replace( "单位质量", "weight"); 

  let json_obj: Value=serde_json::from_str(s.as_str()).unwrap();

  let cdr_str:String=json_obj["cdr"].to_string();
  let gw_str:String=json_obj["gw"].to_string();
  let opgw_str:String=json_obj["opgw"].to_string();

  //println!("{}", cdr_str);
  //println!("{}", gw_str);
  //let deserialized_cdr: Cdr = serde_json::from_str( s.as_str()).unwrap();
  let   deserialized_cdr: Cdr = serde_json::from_str(format!("{}", cdr_str).as_str()).unwrap();
  let   deserialized_gw: Cdr = serde_json::from_str(format!("{}", gw_str).as_str()).unwrap();
  let   deserialized_opgw: Cdr = serde_json::from_str(format!("{}", opgw_str).as_str()).unwrap();

  arr[0][0]=deserialized_cdr.area;
  arr[0][1]=deserialized_cdr.diameter;
  arr[0][2]=deserialized_cdr.linear_co;
  arr[0][3]=deserialized_cdr.elastic_modulus;
  arr[0][4]=deserialized_cdr.rts;
  arr[0][5]=deserialized_cdr.weight;

  arr[1][0]=deserialized_gw.area;
  arr[1][1]=deserialized_gw.diameter;
  arr[1][2]=deserialized_gw.linear_co;
  arr[1][3]=deserialized_gw.elastic_modulus;
  arr[1][4]=deserialized_gw.rts;
  arr[1][5]=deserialized_gw.weight;

  arr[2][0]=deserialized_opgw.area;
  arr[2][1]=deserialized_opgw.diameter;
  arr[2][2]=deserialized_opgw.linear_co;
  arr[2][3]=deserialized_opgw.elastic_modulus;
  arr[2][4]=deserialized_opgw.rts;
  arr[2][5]=deserialized_opgw.weight;





 *st=CCdrs {
      cdr:CCdr {
        name: convert(deserialized_cdr.name),
	    al_nnd: convert(deserialized_cdr.al_nnd),
	    st_nnd: convert(deserialized_cdr.st_nnd),
	    area_al: deserialized_cdr.area_al,
	    area_st: deserialized_cdr.area_st,
	    area: deserialized_cdr.area,
	    diameter: deserialized_cdr.diameter,
	    linear_co: deserialized_cdr.linear_co,
	    elastic_modulus: deserialized_cdr.elastic_modulus,
	    rts: deserialized_cdr.rts,
	    weight: deserialized_cdr.weight 
      },
        gw:CCdr {
        name: convert(deserialized_gw.name),
	    al_nnd: convert(deserialized_gw.al_nnd),
	    st_nnd: convert(deserialized_gw.st_nnd),
	    area_al: deserialized_gw.area_al,
	    area_st: deserialized_gw.area_st,
	    area: deserialized_gw.area,
	    diameter: deserialized_gw.diameter,
	    linear_co: deserialized_gw.linear_co,
	    elastic_modulus: deserialized_gw.elastic_modulus,
	    rts: deserialized_gw.rts,
	    weight: deserialized_gw.weight 
      },
      opgw:CCdr {
        name: convert(deserialized_opgw.name),
	    al_nnd: convert(deserialized_opgw.al_nnd),
	    st_nnd: convert(deserialized_opgw.st_nnd),
	    area_al: deserialized_opgw.area_al,
	    area_st: deserialized_opgw.area_st,
	    area: deserialized_opgw.area,
	    diameter: deserialized_opgw.diameter,
	    linear_co: deserialized_opgw.linear_co,
	    elastic_modulus: deserialized_opgw.elastic_modulus,
	    rts: deserialized_opgw.rts,
	    weight: deserialized_opgw.weight 
      },
  };

  true
}

fn string_to_static_str(s: String) -> &'static str {
    Box::leak(s.into_boxed_str())
}

#[no_mangle]
extern "C" fn qx(json:*const c_char,arr: &mut [[f64;3];14],rtst:&mut Qx)-> *const c_char  //
{
  let c_str: &CStr=unsafe {CStr::from_ptr(json)};
  let str_slice: &str=c_str.to_str().unwrap();
  let mut scli:String=str_slice.to_string();
  scli=scli.replace( "覆冰", "icing"); 
  scli=scli.replace( "基本风速", "wind"); 
  scli=scli.replace( "低温", "low_tempr"); 
  scli=scli.replace( "年平均气温","ave_tempr"); 
  scli=scli.replace( "安装", "stringing"); 
  scli=scli.replace( "高温", "high_tempr"); 
  scli=scli.replace( "操作过电压", "switching"); 
  scli=scli.replace( "雷电过电压", "lightning"); 
  scli=scli.replace( "雷电无风", "lightning_no_wind"); 
  scli=scli.replace( "带电作业", "livework"); 
  scli=scli.replace( "线温", "cdr_tempr"); 
  scli=scli.replace( "断线", "broken"); 
  scli=scli.replace( "验算覆冰", "checking"); 
  scli=scli.replace( "验算", "checking");
  scli=scli.replace( "计算高度", "hc");
  scli=scli.replace( "风速高空指数", "co");
  scli=scli.replace( "计算高最大风速", "max_wind");
  scli=scli.replace( "气象区代号", "qxdh");

 
  let st:Qx =  serde_json::from_str(string_to_static_str(scli)).unwrap();
 
  *rtst= st;
  println!("from rust qxdh={:?}", rtst.qxdh);
  //let qxdh=(deserialized.qxdh+"\0").as_ptr() as *const c_char;
  arr[0]=rtst.icing;
  arr[1]=rtst.wind;
  arr[2]=rtst.low_tempr;
  arr[3]=rtst.ave_tempr;
  arr[4]=rtst.stringing;
  arr[5]=rtst.high_tempr;
  arr[6]=rtst.switching;
  arr[7]=rtst.lightning;
  arr[8]=rtst.lightning_no_wind;
  arr[9]=rtst.livework;
  arr[10]=rtst.cdr_tempr;
  arr[11]=rtst.broken;
  arr[12]=rtst.checking;
  arr[13]=[rtst.hc,rtst.co,rtst.max_wind];
 

 convert(rtst.qxdh.clone().to_string())

}


#[no_mangle]
extern "C" fn root_cubic_simple(b:f64,c:f64,d:f64)->f64
{


	
	let px:f64=-(b.powf(3.0))/27.0-d/2.0+b*c/6.0;
	let deta:f64=px.powf(2.0)+((3.0*c-b.powf(2.0))/9.0).powf(3.0);
	if deta < 0.0 && px < 0.0
	{
	 	let alpha:f64=(-(-deta).sqrt()/px).atan();
		let x1:f64=2.0*(b.powf(2.0)-3.0*c).sqrt()/3.0*((5.0*PI+alpha)/3.0).cos()-b/3.0;
		
		return x1;
	 }   
	else if deta < 0.0 && px > 0.0
	{
		let alpha:f64=((-deta).sqrt()/px).atan();
		let x1:f64=2.0*(b.powf(2.0)-3.0*c).sqrt()/3.0*((6.0*PI+alpha)/3.0).cos()-b/3.0;
		return x1;
	}
	else
	{
		let p1:f64=px+deta.sqrt();
		let p2:f64=px-deta.sqrt();
		let x1:f64=p1.powf(1.0/3.0)+p2.powf(1.0/3.0)-b/3.0;
		
		return x1;
	}	
	
}

#[no_mangle]
extern "C" fn out_of_china(lat: f64, lng: f64) -> bool {
    if lng < 72.004 || lng > 137.8347 {
        return true
    }
    if lat < 0.8293 || lat > 55.8271 {
        return true
    }
    false
}

fn transform(x: f64, y: f64) -> (f64, f64) {
  let xy = x * y;
  let abs_x = x.abs().sqrt();
  let x_pi = x * PI;
  let y_pi = y * PI;
  let d = 20.0*(6.0*x_pi).sin() + 20.0*(2.0*x_pi).sin();

  let mut lat = d;
  let mut lng = d;

  lat += 20.0*(y_pi).sin() + 40.0*(y_pi/3.0).sin();
  lng += 20.0*(x_pi).sin() + 40.0*(x_pi/3.0).sin();

  lat += 160.0*(y_pi/12.0).sin() + 320.0*(y_pi/30.0).sin();
  lng += 150.0*(x_pi/12.0).sin() + 300.0*(x_pi/30.0).sin();

  lat *= 2.0 / 3.0;
  lng *= 2.0 / 3.0;

  lat += -100.0 + 2.0*x + 3.0*y + 0.2*y*y + 0.1*xy + 0.2*abs_x;
  lng += 300.0 + x + 2.0*y + 0.1*x*x + 0.1*xy + 0.1*abs_x;

  (lat, lng)
}

fn delta(lat: f64, lng: f64) -> (f64, f64) {
  let ee = 0.00669342162296594323;
  let (d_lat, d_lng) = transform(lng-105.0, lat-35.0);
    let mut d_lat = d_lat;
    let mut d_lng = d_lng;
  let rad_lat = lat / 180.0 * PI;
  let mut magic = (rad_lat).sin();
  magic = 1.0 - ee*magic*magic;
  let sqrt_magic = (magic).sqrt();
  d_lat = (d_lat * 180.0) / ((WGS84_A * (1.0 - ee)) / (magic * sqrt_magic) * PI);
  d_lng = (d_lng * 180.0) / (WGS84_A / sqrt_magic * (rad_lat).cos() * PI);
  (d_lat, d_lng)
}

// wgs2gcj convert WGS-84 coordinate(wgs_lat, wgs_lng) to GCJ-02 coordinate.
#[no_mangle]
extern "C" fn wgs2gcj(wgs_lat: f64, wgs_lng: f64) -> (f64,f64) {
  if out_of_china(wgs_lat, wgs_lng) {   
    return (wgs_lat,wgs_lng);
  }
  let (d_lat, d_lng) = delta(wgs_lat, wgs_lng);
    (wgs_lat+d_lat, wgs_lng+d_lng)
}

// gcj2wgs convert GCJ-02 coordinate(gcj_lat, gcj_lng) to WGS-84 coordinate.
// The output WGS-84 coordinate's accuracy is 1m to 2m. If you want more exactly result, use gcj2wgs_exact.
#[no_mangle]
extern "C" fn gcj2wgs(gcj_lat: f64, gcj_lng: f64) -> (f64,f64) {
  if out_of_china(gcj_lat, gcj_lng) {
    return (gcj_lat, gcj_lng);

  }
  let (d_lat, d_lng) = delta(gcj_lat, gcj_lng);
  (gcj_lat-d_lat, gcj_lng-d_lng)
}

// gcj2wgs_exact convert GCJ-02 coordinate(gcj_lat, gcj_lng) to WGS-84 coordinate.
// The output WGS-84 coordinate's accuracy is less than 0.5m, but much slower than gcj2wgs.
#[no_mangle]
extern "C" fn gcj2wgs_exact(gcj_lat: f64, gcj_lng: f64,res:&mut [f64;2]) ->bool {
  const INIT_DELTA: f64 = 0.01;//0.01 org
  const THRESHOLD: f64 = 0.000001;//0.000001 org
  let mut d_lat = INIT_DELTA;
  let mut d_lng = INIT_DELTA;
    let mut m_lat = gcj_lat - d_lat;
    let mut m_lng = gcj_lng - d_lng;
    let mut p_lat = gcj_lat + d_lat;
    let mut p_lng = gcj_lng + d_lng;

  for _ in 0..100 {
    let (wgs_lat, wgs_lng) = ( (m_lat+p_lat)/2.0, (m_lng+p_lng)/2.0 );
    let (tmp_lat, tmp_lng) = wgs2gcj(wgs_lat, wgs_lng);
    d_lat = tmp_lat-gcj_lat;
    d_lng = tmp_lng-gcj_lng;
    if d_lat.abs() < THRESHOLD && d_lng.abs() < THRESHOLD {
      //(wgs_lat, wgs_lng);
      res[0]=wgs_lat;
      res[1]=wgs_lng;
      return true;
      
    }
    if d_lat > 0.0 {
      p_lat = wgs_lat;
    } else {
      m_lat = wgs_lat;
    }
    if d_lng > 0.0 {
      p_lng = wgs_lng;
    } else {
      m_lng = wgs_lng;
    }
  }
  //( (m_lat+p_lat)/2.0, (m_lng+p_lng)/2.0 )
  res[0]=(m_lat+p_lat)/2.0;
  res[1]=(m_lng+p_lng)/2.0;
  true
}

// distance calculate the distance between point(lat_a, lng_a) and point(lat_b, lng_b), unit in meter.
#[no_mangle]
extern "C" fn distance(lat_a: f64, lng_a: f64, lat_b: f64, lng_b: f64) -> f64 {
  let arc_lat_a = lat_a * PI / 180.0;
  let arc_lat_b = lat_b * PI / 180.0;
  let x = (arc_lat_a).cos() * (arc_lat_b).cos() * ((lng_a-lng_b)*PI/180.0).cos();
  let y = (arc_lat_a).sin() * (arc_lat_b).sin();
  let mut s = x + y;
  if s > 1.0 {
    s = 1.0
  }
  if s < -1.0 {
    s = -1.0
  }
  let alpha = s.acos();
    alpha * WGS84_A
}



#[repr(C)]
 struct UTMCoor 
 {
      x:f64,
      y:f64,
 }
 #[repr(C)]
 struct WGS84Corr
 {
      lat:f64,
      log:f64,
 }
 /*
 * deg_to_rad
 *
 * Converts degrees to radians.
 *
 */
#[no_mangle]
 extern "C" fn deg_to_rad(deg:f64)->f64
 {
     deg / 180.0 * PI
 }
 
 /*
 * rad_to_deg
 *
 * Converts radians to degrees.
 *
 */
 #[no_mangle]
 extern "C" fn rad_to_deg(rad:f64)->f64
 {
     rad / PI * 180.0
 }
 
 /*
 * arc_length_of_meridian
 *
 * Computes the ellipsoidal distance from the equator to a point at a
 * given latitude.
 *
 * Reference: Hoffmann-Wellenhof, B., Lichtenegger, H., and Collins, J.,
 * GPS: Theory and Practice, 3rd ed.  New York: Springer-Verlag Wien, 1994.
 *
 * Inputs:
 *     phi - Latitude of the point, in radians.
 *
 * Globals:
 *     WGS84_A - Ellipsoid model major axis.
 *     WGS84_B - Ellipsoid model minor axis.
 *
 * Returns:
 *     The ellipsoidal distance of the point from the equator, in meters.
 *
 */
#[no_mangle]
 extern "C" fn arc_length_of_meridian(phi:f64)->f64
 {
   let result:f64=arc_length_of_meridian_u(WGS84_A,WGS84_F,phi);
 
      result
 }

 #[no_mangle]
 extern "C" fn arc_length_of_meridian_u(a:f64,f:f64,phi:f64)->f64
 {   
     let n:f64=2.0*f-f*f;//e^2
 
     /* Precalculate alpha */
     let alpha:f64 = 1.0+3.0/4.0*n+45.0/64.0*n.powf(2.0)+175.0/256.0*n.powf(3.0)+11025.0/16384.0*n.powf(4.0)+43659.0/65536.0*n.powf(5.0);//+693693.0/1048576.0*n.powf(6.0);
 
     /* Precalculate beta */
     let beta:f64 = 3.0*n/8.0+15.0/32.0*n.powf(2.0)+525.0/1024.0*n.powf(3.0)+2205.0/4096.0*n.powf(4.0)+72765.0/131072.0*n.powf(5.0);//+297297.0/524288.0*n.powf(6.0);
 
 
     /* Precalculate gamma */
     let gamma:f64 = 15.0/256.0*n.powf(2.0)+105.0/1024.0*n.powf(3.0)+2205.0/16384.0*n.powf(4.0)+10395.0/65536.0*n.powf(5.0);//+1486485.0/8388608.0*n.powf(6.0);
 
 
     /* Precalculate delta */
     let delta:f64 = 35.0/3072.0*n.powf(3.0)+105.0/4096.0*n.powf(4.0)+10395.0/262144.0*n.powf(5.0);//+55055.0/1048576.0*n.powf(6.0);
 
 
     /* Precalculate epsilon */
     let epsilon:f64 = 315.0/131072.0*n.powf(4.0)+3465.0/524288.0*n.powf(5.0);//+99099.0/8388608.0*n.powf(6.0);
    

      /* Precalculate eta */
     let eta:f64 = 693.0/1310720.0*n.powf(5.0);//+9009.0/5242880.0*n.powf(6.0);

     /* Precalculate sita */
     //let sita:f64 = 1001.0/8388608.0*n.powf(6.0);

     /* Now calculate the sum of the series and return */
     let result:f64 = a*(1.0-n) * (alpha*phi - 
      (beta * (2.0 * phi).sin()) + 
      (gamma * (4.0 * phi).sin()) - 
      (delta * (6.0 * phi).sin()) + 
      (epsilon * (8.0 * phi).sin())-
      (eta * (10.0 * phi).sin()) //+
      //(sita * (12.0 * phi).sin())
      );
 
      result
 }
 /*
 * utm_central_meridian
 *
 * Determines the central meridian for the given UTM zone.
 *
 * Inputs:
 *     zone - An integer value designating the UTM zone, range [1,60].
 *
 * Returns:
 *   The central meridian for the given UTM zone, in radians, or zero
 *   if the UTM zone parameter is outside the range [1,60].
 *   Range of the central meridian is the radian equivalent of [-177,+177].
 *
 */
#[no_mangle]
extern "C" fn utm_central_meridian(zone:i32)->f64
 {
     return deg_to_rad(-180.0+3.0 + (((zone-1) as f64)* 6.0));
 }
 
 /*
 * foot_point_latitude
 *
 * Computes the footpoint latitude for use in converting transverse
 * Mercator coordinates to ellipsoidal coordinates.
 *
 * Reference: Hoffmann-Wellenhof, B., Lichtenegger, H., and Collins, J.,
 *   GPS: Theory and Practice, 3rd ed.  New York: Springer-Verlag Wien, 1994.
 *
 * Inputs:
 *   y - The UTM northing coordinate, in meters.
 *
 * Returns:
 *   The footpoint latitude, in radians.
 *
 */
 #[no_mangle]
 extern "C" fn foot_point_latitude(a:f64,f:f64,y:f64)->f64
 {
   let  y_:f64;
   let  alpha0:f64;
   let  alpha_:f64;
   let  beta_:f64;
   let  gamma_:f64;
   let  delta_:f64;
   let  epsilon_:f64;
   
   //let  edd_:f64;
   let  n:f64;
   
   let   result:f64;
   //let b:f64=a*(1.0-f);
   n=2.0*f-f*f;//e^2
     /* Precalculate n (Eq. 10.18) */
    
 
     /* Precalculate alpha_ (Eq. 10.22) */
     /* (Same as alpha in Eq. 10.17) */
     alpha0 = 1.0+3.0/4.0*n+45.0/64.0*n.powf(2.0)+175.0/256.0*n.powf(3.0)+11025.0/16384.0*n.powf(4.0)+
     43659.0/65536.0*n.powf(5.0);
 
    
     y_ = y / alpha0/a/(1.0-n);
     alpha_=3.0/8.0*n+3.0/16.0*n.powf(2.0)+213.0/2048.0*n.powf(3.0)+255.0/4096.0*n.powf(4.0)+
     20861.0/524288.0*n.powf(5.0);
     
     beta_ = 21.0/256.0*n.powf(2.0)+21.0/256.0*n.powf(3.0)+533.0/8192.0*n.powf(4.0)+
     197.0/4096.0*n.powf(5.0);
 
     
     gamma_ = 151.0/6144.0*n.powf(3.0)+151.0/4096.0*n.powf(4.0)+5019.0/131072.0*n.powf(5.0);
 
    
     delta_ = 1097.0/131072.0*n.powf(4.0)+1097.0/65536.0*n.powf(5.0);
 
     
     epsilon_ = 8011.0 * n.powf(5.0) / 2621440.0;
 
     /* Now calculate the sum of the series (Eq. 10.21) */
     result = y_ +  alpha_* (2.0 * y_).sin() + 
      beta_* (4.0 * y_).sin() + 
      gamma_* (6.0 * y_).sin() + 
      delta_* (8.0 * y_).sin()+
      epsilon_ * (10.0 * y_).sin();
 
      result
 }
 
 /*
 * map_lat_lon_to_xy
 *
 * Converts a latitude/longitude pair to x and y coordinates in the
 * Transverse Mercator projection.  Note that Transverse Mercator is not
 * the same as UTM; a scale factor is required to convert between them.
 *
 * Reference: Hoffmann-Wellenhof, B., Lichtenegger, H., and Collins, J.,
 * GPS: Theory and Practice, 3rd ed.  New York: Springer-Verlag Wien, 1994.
 *
 * Inputs:
 *    phi - Latitude of the point, in radians.
 *    lambda - Longitude of the point, in radians.
 *    lambda0 - Longitude of the central meridian to be used, in radians.
 *
 * Outputs:
 *    xy - A 2-element array containing the x and y coordinates
 *         of the computed point.
 *
 * Returns:
 *    The function does not return a value.
 *
 */
 #[no_mangle]
 extern "C" fn map_lat_lon_to_xy(a:f64,f:f64,phi:f64,lambda:f64,lambda0:f64,xy:&mut UTMCoor)
 {
   let b=(1.0-f)*a;
   let e=(1.0-(b/a).powf(2.0)).sqrt();
   let e2_=2.0*f-f*f;
   let e1=((a/b).powf(2.0)-1.0).sqrt();

   let m_=a*((1.0-e2_/4.0-3.0/64.0*e2_.powf(2.0)-5.0/256.0*e2_.powf(3.0))*phi-
     (3.0*e2_/8.0+3.0/32.0*e2_.powf(2.0)+45.0/1024.0*e2_.powf(3.0))*(2.0*phi).sin()+
     (15.0/256.0*e2_.powf(2.0)+45.0/1024.0*e2_.powf(3.0))*(4.0*phi).sin()-35.0/3072.0*e2_.powf(3.0)*(6.0*phi).sin() );
   //let m_=arc_length_of_meridian_u(a,f,phi);

   let n_=a/(1.0-(e*phi.sin()).powf(2.0)).sqrt();
   let aa_=(lambda-lambda0)*phi.cos()/3600.0;
   let t_=phi.tan().powf(2.0);
   let c_=(e1*phi.cos()).powf(2.0);
    xy.y=m_+n_*phi.tan()*(aa_.powf(2.0)/2.0+(5.0-t_+9.0*c_+4.0*c_.powf(2.0))*aa_.powf(4.0)/24.0)+
   (61.0-58.0*t_+t_.powf(2.0)+600.0*c_-330.0*e1.powf(2.0))*aa_.powf(6.0)/720.0;
    xy.x=n_*(aa_+(1.0-t_+c_)*aa_.powf(3.0)/6.0+(5.0-18.0*t_+t_.powf(2.0)+72.0*c_-58.0*e1.powf(2.0))*aa_.powf(5.0)/120.0);
    xy.x=xy.x*1000.0;
    xy.y=xy.y*1000.0

 }
 
 

 
 /*
 * LatLonToUTMXY
 *
 * Converts a latitude/longitude pair to x and y coordinates in the
 * Universal Transverse Mercator projection.
 *
 * Inputs:
 *   lat - Latitude of the point, in radians.
 *   lon - Longitude of the point, in radians.
 *   zone - UTM zone to be used for calculating values for x and y.
 *          If zone is less than 1 or greater than 60, the routine
 *          will determine the appropriate zone from the value of lon.
 *
 * Outputs:
 *   xy - A 2-element array where the UTM x and y values will be stored.
 *
 * Returns:
 *   void
 *
 */
 #[no_mangle]
 extern "C" fn lat_lon_to_utm_xy( lat:f64,  lon:f64,  zone:i32, xy:&mut UTMCoor)
 {
     map_lat_lon_to_xy(WGS84_A,WGS84_F,lat, lon, utm_central_meridian(zone), xy);
 
     /* Adjust easting and northing for UTM system. */
     xy.x=xy.x*UTM_SCALE_FACTOR+500000.0;
     xy.y=xy.y*UTM_SCALE_FACTOR;
     if xy.y<0.0
     {    
     xy.y+=10000000.0;
     }
 }
 
 
 /*
 * map_xy_to_lat_lon
 *
 * Converts x and y coordinates in the Transverse Mercator projection to
 * a latitude/longitude pair.  Note that Transverse Mercator is not
 * the same as UTM; a scale factor is required to convert between them.
 *
 * Reference: Hoffmann-Wellenhof, B., Lichtenegger, H., and Collins, J.,
 *   GPS: Theory and Practice, 3rd ed.  New York: Springer-Verlag Wien, 1994.
 *
 * Inputs:
 *   x - The easting of the point, in meters.
 *   y - The northing of the point, in meters.
 *   lambda0 - Longitude of the central meridian to be used, in radians.
 *
 * Outputs:
 *   philambda - A 2-element containing the latitude and longitude
 *               in radians.
 *
 * Returns:
 *   The function does not return a value.
 *
 * Remarks:
 *   The local variables _nnf, nuf2, tf, and tf2 serve the same purpose as
 *   N, nu2, t, and t2 in map_lat_lon_to_xy, but they are computed with respect
 *   to the footpoint latitude phif.
 *
 *   x1frac, x2frac, x2poly, x3poly, etc. are to enhance readability and
 *   to optimize computations.
 *
 */
 
 #[no_mangle]
 extern "C" fn map_xy_to_lat_lon(a:f64,f:f64, x:f64, y:f64, lambda0:f64,philambda:&mut WGS84Corr)
 {
    let b=(1.0-f)*a;
    let e=(1.0-(b/a).powf(2.0)).sqrt();
    //let e2_=2.0*f-f*f;
    let e1=(1.0-b/a)/(1.0+b/a);
      //k0 = 0.9996
    let bf_=foot_point_latitude(a,f,y);
    let nf_=a.powf(2.0)/b/(1.0+e1.powf(2.0)*bf_.powf(2.0)).sqrt();
    let rf_=a*(1.0-e.powf(2.0))/(1.0-(e*bf_.sin()).powf(2.0)).powf(1.5);
    //let mf_=y;
    //let fai_=mf_/(a*(1.0-e2_/4.0-3.0*e2_.powf(2.0)-5.0/256.0*e2_.powf(3.0)));
    let tf_=bf_.tan().powf(2.0);
    let cf_=(e1*bf_.cos()).powf(2.0);
    let d_=x/nf_;

      philambda.lat =bf_-nf_*bf_.tan()/rf_*(d_.powf(2.0)/2.0-(5.0+3.0*tf_+10.0*cf_-4.0*cf_.powf(2.0)-9.0*e1.powf(2.0))*d_.powf(4.0)/24.0+
        (61.0+90.0*tf_+298.0*cf_+45.0*tf_.powf(2.0)-252.0*e1.powf(2.0)-3.0*cf_.powf(2.0)  )*d_.powf(6.0)/720.0);
      let lon_tmp=1.0/bf_.cos()*(d_-(1.0+2.0*tf_+cf_)*d_.powf(3.0)/6.0+(5.0-2.0*cf_+28.0*tf_-3.0*cf_.powf(2.0)+
        8.0*e1.powf(2.0)+24.0*tf_.powf(2.0))*d_.powf(5.0)/120.0  );
      philambda.log = lambda0 + lon_tmp;
      
 }
 /*
 * UTMXYToLatLon
 *
 * Converts x and y coordinates in the Universal Transverse Mercator
 * projection to a latitude/longitude pair.
 *
 * Inputs:
 *    x - The easting of the point, in meters.
 *    y - The northing of the point, in meters.
 *    zone - The UTM zone in which the point lies.
 *    southhemi - True if the point is in the southern hemisphere;
 *               false otherwise.
 *
 * Outputs:
 *    latlon - A 2-element array containing the latitude and
 *            longitude of the point, in radians.
 *
 * Returns:
 *    The function does not return a value.
 *
 */
#[no_mangle]
 extern "C" fn  utm_xy_to_lat_lon( mut x:f64,  mut y:f64,  zone:i32,  southhemi:bool, latlon:&mut WGS84Corr)
 {
     let  cmeridian:f64;
 
     x-= 500000.0;
     x/= UTM_SCALE_FACTOR;
 
     /* If in southern hemisphere, adjust y accordingly. */
     if southhemi==true
   {   
     y-= 10000000.0;
   }
 
     y/= UTM_SCALE_FACTOR;
     cmeridian = utm_central_meridian(zone);
     map_xy_to_lat_lon(WGS84_A,WGS84_F,x, y, cmeridian, latlon);
 }



///////////////////////////////////////////////////////////////
pub struct Geodesic {
    g: geodesic::Struct_geod_geodesic,
}

impl Geodesic {
    /// Constructs a `Geodesic` with equatorial radius `a` (metres)
    /// and flattening `f`.
    pub fn new(a: f64, f: f64) -> Geodesic {
        let mut g = geodesic::Struct_geod_geodesic::default();
        unsafe {
            geodesic::geod_init(&mut g, a, f);
        }
        Geodesic { g: g }
    }

    /// Constructs a `Geodesic` according to the WGS84 ellipsoid.
    pub fn wgs84() -> Geodesic {
        Geodesic::new(WGS84_A, WGS84_F)
    }
    pub fn direct(&self, lat1: f64, lon1: f64, azi1: f64, s12: f64) -> (f64, f64, f64) {
        let mut lat2 = std::f64::NAN;
        let mut lon2 = std::f64::NAN;
        let mut azi2 = std::f64::NAN;
        unsafe {
            geodesic::geod_direct(&self.g,
                                  lat1,
                                  lon1,
                                  azi1,
                                  s12,
                                  &mut lat2,
                                  &mut lon2,
                                  &mut azi2);
        }
        (lat2, lon2, azi2)
    }
    pub fn inverse(&self, lat1: f64, lon1: f64, lat2: f64, lon2: f64) -> (f64, f64, f64) {
        let mut s12 = std::f64::NAN;
        let mut azi1 = std::f64::NAN;
        let mut azi2 = std::f64::NAN;
        unsafe {
            geodesic::geod_inverse(&self.g,
                                   lat1,
                                   lon1,
                                   lat2,
                                   lon2,
                                   &mut s12,
                                   &mut azi1,
                                   &mut azi2);
        }
        (s12, azi1, azi2)
    }
}

#[no_mangle]
extern "C" fn geo_direct(lat1: f64, lon1: f64, azi1: f64, s12: f64,res:&mut [f64;3])
{
  let wgs=Geodesic::wgs84();
  let lat2:f64;
  let mut lon2:f64;
  let azi2:f64;
  let _t=wgs.direct(lat1, lon1, azi1, s12);
  lat2=_t.0;
  lon2=_t.1;
  azi2=_t.2;

  if lon2 < -180.0 
  {
     lon2 += 360.0;
  }
 if lon2 > 180.0 
 {
    lon2 -= 360.0;
 }
  res[0]=lat2;
  res[1]=lon2;
  res[2]=azi2;
}
#[no_mangle]
extern "C" fn geo_inverse(lat1: f64, lon1: f64, lat2: f64, lon2: f64,res:&mut [f64;3])
{
  let wgs=Geodesic::wgs84();
  //let s12:f64;
  //let azi1:f64;
  //let azi2:f64;
  let _t=wgs.inverse(lat1, lon1, lat2, lon2);
  res[0]=_t.0;
  res[1]=_t.1;
  res[2]=_t.2;
}
/*
pub struct Geotm {
    g: geotm::Struct_geo_transverse_mercator,
}

impl Geotm {
    /// Constructs a `Geodesic` with equatorial radius `a` (metres)
    /// and flattening `f`.
    pub fn new() -> Geotm {
        let mut g = geotm::Struct_geo_transverse_mercator::default();
        unsafe {
            geotm::geo_transverse_mercator_init(&mut g);
            
        }
        Geotm { g: g }
    }
    pub fn init(&self, a: f64, f: f64,k0:f64)  {
       
        unsafe {
            geotm::geo_transverse_mercator_start(&self.g,a,f,k0);
        }
    }
    pub fn forward(&self, lon0: f64, lat: f64, lon: f64, x: *mut f64,y:*mut f64)  {
       
        unsafe {
            geotm::geo_transverse_mercator_forward(&self.g,
                                  lon0,
                                  lat,
                                  lon,
                                   x,
                                  y);
        }
    }
    pub fn reverse(&self, lon0:f64,x: f64, y: f64,  lat: *mut f64,lon:*mut f64)  {
       
        unsafe {
            geotm::geo_transverse_mercator_reverse(&self.g,
                                  lon0,
                                  x,
                                  y,
                                  lat,
                                  lon);
        }
    }
}

#[no_mangle]
extern "C" fn geotm_forward(a:f64,f:f64,k0:f64,lon0:f64,lat:f64,lon:f64,x: *mut f64,y: *mut f64){

	let wgs=Geotm::new();
  wgs.init(a,f,k0);
	wgs.forward(lon0,lat,lon,x,y);

}

#[no_mangle]
extern "C" fn geotm_reverse(a:f64,f:f64,k0:f64,lon0:f64,x:f64,y:f64,lat: *mut f64,lon: *mut f64){

	let wgs=Geotm::new();
  wgs.init(a,f,k0);
	wgs.reverse(lon0,x,y,lat,lon);

}
*/