
#ifndef _TRANSVERRSEMERCATORWRAPPER_H__  
#define _TRANSVERRSEMERCATORWRAPPER_H__  

#ifdef	_EXPORTDLL
#define _LIBAPI __declspec(dllexport)
#else
#define _LIBAPI __declspec(dllimport)
#endif

struct geo_transverse_mercator;  
#ifdef __cplusplus  
extern "C" {  
#endif  

_LIBAPI struct geo_transverse_mercator *geo_transverse_mercator_init(void);  
_LIBAPI void geo_transverse_release_instance(struct geo_transverse_mercator  **ppInstance); 
_LIBAPI extern void geo_transverse_mercator_start(struct geo_transverse_mercator  *pTransversMercator,double a, double f, double k0); 
_LIBAPI extern void geo_transverse_mercator_forward(struct geo_transverse_mercator  *pTransversMercator,double lon0, double lat, double lon,
                 double& x, double& y );  
_LIBAPI extern void geo_transverse_mercator_reverse(struct geo_transverse_mercator  *pTransversMercator,double lon0, double x, double y,
                 double& lat, double& lon ); 
#ifdef __cplusplus  
};  
#endif  

#endif  

